﻿using System;
using System.Linq;

namespace Tty.DeferredQuery.One
{
    class Program
    {
        static double Square(double n)
        {
            Console.WriteLine("Computing Square(" + n + ")...");
            return Math.Pow(n, 2);
        }

        static void Main(string[] args)
        {
            int[] numbers = {1, 2, 3};

            var query = numbers.Select(n => Square(n));
                //from n in numbers
                //select Square(n);

            foreach(var n in query)
                Console.WriteLine(n);

            Console.Read();
        }
    }
}
