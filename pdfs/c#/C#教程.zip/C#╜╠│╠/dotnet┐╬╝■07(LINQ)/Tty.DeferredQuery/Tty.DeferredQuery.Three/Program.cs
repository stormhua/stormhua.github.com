﻿using System;
using System.Linq;

namespace Tty.DeferredQuery.Three
{
    class Program
    {
        static double Square(double n)
        {
            Console.WriteLine("Computing Square(" + n + ")...");
            return Math.Pow(n, 2);
        }

        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3 };

            var query =
                from n in numbers
                select Square(n);

            Console.WriteLine("- 延迟查询执行 -");
            foreach (var n in query)
                Console.WriteLine(n);

            Console.WriteLine("- 强制查询立即执行 -");
            foreach (var n in query.ToList())
                Console.WriteLine(n);

            Console.Read();
        }
    }
}
