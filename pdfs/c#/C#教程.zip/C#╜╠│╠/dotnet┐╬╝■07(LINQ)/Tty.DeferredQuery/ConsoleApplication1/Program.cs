﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList AL = new ArrayList();

            AL.Add(1);

            AL.Add(2);

            AL.Add("3");

            AL.Add(4);

            var que = AL.OfType<string>();

            foreach (var i in que)
            {

                Console.WriteLine(i);

            }
            Console.Read();
        }

    }
}
