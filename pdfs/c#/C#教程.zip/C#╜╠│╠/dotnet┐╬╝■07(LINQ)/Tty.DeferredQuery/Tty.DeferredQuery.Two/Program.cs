﻿using System;
using System.Linq;

namespace Tty.DeferredQuery.Two
{
    class Program
    {
        static double Square(double n)
        {
            Console.WriteLine("Computing Square(" + n + ")...");
            return Math.Pow(n, 2);
        }

        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3 };

            var query =
                from n in numbers
                select Square(n);

            foreach (var n in query)
                Console.WriteLine(n);

            for (int i = 0; i < numbers.Length; i++)
                numbers[i] = numbers[i] + 10;

            Console.WriteLine("- 集合更新后 -");

            foreach(var n in query)
                Console.WriteLine(n);

            Console.Read();
        }
    }
}
