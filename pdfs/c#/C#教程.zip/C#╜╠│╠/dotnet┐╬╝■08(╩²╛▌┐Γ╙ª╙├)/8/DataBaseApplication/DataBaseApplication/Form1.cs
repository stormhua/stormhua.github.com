﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataBaseApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //System.Configuration.ConfigurationManager.ConnectionStrings
                string myConStr = "Data Source=tty1;Initial Catalog=Northwind;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(myConStr);
                myCon.Open();
                SqlCommand myCom = new SqlCommand("select * from employees", myCon);
                SqlDataReader myReader = myCom.ExecuteReader();
                BindingSource bindingSource = new BindingSource();
                bindingSource.DataSource = myReader;
                dataGridView1.DataSource = bindingSource;
                myCon.Close();
                
            }
            catch
            {
            }
        }
    }
}