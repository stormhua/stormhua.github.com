using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataBaseApplication
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet dsStudent = new DataSet();
                DataTable dtStudent = new DataTable("Student");
                dsStudent.Tables.Add(dtStudent);
                dtStudent.Columns.Add(new DataColumn("ID"));
                dtStudent.Columns.Add(new DataColumn("Name"));
                dtStudent.Columns.Add(new DataColumn("Sex"));

                DataRow drNew = dtStudent.NewRow();
                drNew["ID"] = tbID.Text;
                drNew["Name"] = tbName.Text;
                if (rbMan.Checked)
                    drNew["Sex"] = rbMan.Text;
                else
                    drNew["Sex"] = rbWoman.Text;

                dtStudent.Rows.Add(drNew);

                string myConStr = "Data Source=tty1;Initial Catalog=StudentInfo;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(myConStr);
                myCon.Open();

                SqlCommand myCom = new SqlCommand();
                myCom.Connection = myCon;
                myCom.CommandType = CommandType.Text;
                myCom.CommandText = "insert into Student(ID,Name,Sex)Values(@ID,@Name,@Sex)";
                myCom.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar, 10));
                myCom.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar, 15));
                myCom.Parameters.Add(new SqlParameter("@Sex", SqlDbType.NVarChar, 1));
                myCom.Parameters["@ID"].SourceColumn = "ID";
                myCom.Parameters["@Name"].SourceColumn = "Name";
                myCom.Parameters["@Sex"].SourceColumn = "Sex";

                SqlDataAdapter myAdapter = new SqlDataAdapter();
                myAdapter.InsertCommand = myCom;
                if( myAdapter.Update(dsStudent,"Student") > 0 )
                    MessageBox.Show("���ӳɹ�");
                myCon.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}