using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataBaseApplication
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                string myConStr = "Data Source=(local);Initial Catalog=Northwind;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(myConStr);
                myCon.Open();

                SqlCommand myCom = new SqlCommand();
                myCom.Connection = myCon;
                myCom.CommandType = CommandType.StoredProcedure;
                myCom.CommandText = "CustOrderHist";
                myCom.Parameters.Add("@CustomerID", SqlDbType.NChar, 5);
                myCom.Parameters["@CustomerID"].Value = "ALFKI";

                SqlDataAdapter myAdapter = new SqlDataAdapter();
                myAdapter.SelectCommand = myCom;
                DataSet dataSet = new DataSet();
                myAdapter.Fill(dataSet);
                dataGridView1.DataSource = dataSet.Tables[0];
                myCon.Close();
            }
            catch
            {
            }
        }
    }
}