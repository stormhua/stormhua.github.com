using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace DataBaseApplication
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            try
            {
                string myConStr = "Provider=Microsoft.Jet.OLEDB.4.0;";
                myConStr += "Data Source=Library.mdb;";
                OleDbConnection myCon = new OleDbConnection(myConStr);
                myCon.Open();
                string mySQL = "select * from BookInfo";
                OleDbCommand myCom = new OleDbCommand(mySQL, myCon);
                OleDbDataReader myReader = myCom.ExecuteReader();
                BindingSource bindingSource = new BindingSource();
                bindingSource.DataSource = myReader;
                dataGridView1.DataSource = bindingSource;
                myCon.Close();
            }
            catch
            {
            }
        }
    }
}