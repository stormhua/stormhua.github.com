﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Linq;
using System.Text;

namespace Tty.CSharp3.Seven
{
    public class Program
    {
        //public class ProcessData
        //{
        //    public int Id { get; set; }

        //    public long Memory { get; set; }

        //    public string Name { get; set; }
        //}

        static void DisplayProcesses()
        {
            var processes = new List<object>();
            foreach (var process in Process.GetProcesses())
            {
                processes.Add(
                    new 
                    {
                        Id = process.Id,
                        Name = process.ProcessName,
                        Memory = process.WorkingSet64
                    }
                );
            }

            Display(processes);
        }

        static void Display(List<object> processes)
        {
            foreach (var process in processes)
            {
                Type type = process.GetType();
                PropertyInfo piId = type.GetProperty("Id");
                PropertyInfo piMemory = type.GetProperty("Memory");
                PropertyInfo piName = type.GetProperty("Name");

                Console.WriteLine(
                    "{0}\t{1}\t{2}", 
                    piId.GetValue(process,null), 
                    piMemory.GetValue(process,null), 
                    piName.GetValue(process,null)
                );
            }
        }

        static void Main()
        {
            DisplayProcesses();
            Console.Read();
        }
    }
}
