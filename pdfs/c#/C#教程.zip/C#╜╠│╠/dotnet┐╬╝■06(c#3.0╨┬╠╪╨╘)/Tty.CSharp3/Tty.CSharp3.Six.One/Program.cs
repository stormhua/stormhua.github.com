﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Tty.CSharp3.Six.One
{
    public class Program
    {
        public class ProcessData
        {
            public int Id { get; set; }

            public long Memory { get; set; }

            public string Name { get; set; }
        }

        static void DisplayProcesses()
        {
            var processes = new List<ProcessData>();
            foreach (var process in Process.GetProcesses())
            {
                processes.Add(new ProcessData{Id = process.Id,Name = process.ProcessName,Memory = process.WorkingSet64});
            }

            Console.WriteLine("Total memory:{0} MB",TotalMemory(processes)/1024/1024);
        }

        static Int64 TotalMemory(List<ProcessData> processes)
        {
            Int64 result = 0;
            foreach(var process in processes)
                result += process.Memory;
            return result;
        }

        static void Main()
        {
            DisplayProcesses();
            Console.Read();
        }
    }
}
