﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tty.CSharp3.Six.Three
{
    class Class1
    {
        
    }

    class Class2
    {
        public void Method1(string s)
        {
            Console.WriteLine("Class2.Method1");
        }
    }

    class Class3
    {
        public void Method1(object o)
        {
            Console.WriteLine("Class3.Method1");
        }

        public void Method1(int i)
        {
            Console.WriteLine("Class3.Method2");
        }
    }

    class Class4
    {
        public void Method1(int i)
        {
            Console.WriteLine("Class4.Method1");
        }
    }

    static class Extensions
    {
        static public void Method1(this object o, int i)
        {
            Console.WriteLine("Extensions.Method1");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            new Class1().Method1(12);//调用了扩展方法
            new Class2().Method1(12);//调用了扩展方法
            new Class3().Method1(12);//调用实例方法
            new Class4().Method1(12);//调用实例方法
            Console.Read();
        }
    }
}
