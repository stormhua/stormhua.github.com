﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Tty.CSharp3.Four
{
    public class Program
    {
        public class ProcessData
        {
            public int Id { get; set; }

            public long Memory { get; set; }

            public string Name { get; set; }
        }

        static void DisplayProcesses()
        {
            var processes = new List<ProcessData>();
            foreach (var process in Process.GetProcesses())
            {
                processes.Add(
                    new ProcessData
                        {
                            Id = process.Id,
                            Name = process.ProcessName,
                            Memory = process.WorkingSet64
                        }
                    );
            }

            Display(processes);
        }

        static void Display(List<ProcessData> processes)
        {
            foreach (var process in processes)
            {
                Console.WriteLine("{0}\t{1}\t{2}", process.Id, process.Memory, process.Name);
            }
        }

        static void Main()
        {
            DisplayProcesses();
            Console.Read();
        }
    }
}
