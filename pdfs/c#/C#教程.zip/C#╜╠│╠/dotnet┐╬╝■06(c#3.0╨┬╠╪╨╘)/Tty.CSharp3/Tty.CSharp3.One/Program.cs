﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Tty.CSharp3.One
{
    public class Program
    {
        public class ProcessData
        {
            private int _id;
            public int Id
            {
                get { return _id; }
                set { _id = value; }
            }

            private long _memory;
            public long Memory
            {
                get { return _memory; }
                set { _memory = value; }
            }

            private string _name;
            public string Name
            {
                get { return _name; }
                set { _name = value; }
            }
        }

        static void DisplayProcesses()
        {
            List<ProcessData> processes = new List<ProcessData>();
            foreach (Process process in Process.GetProcesses())
            {
                ProcessData data = new ProcessData();
                data.Id = process.Id;
                data.Name = process.ProcessName;
                data.Memory = process.WorkingSet64;
                processes.Add(data);
            }

            Display(processes);
        }

        static void Display(List<ProcessData> processes)
        {
            foreach (ProcessData process in processes)
            {
                Console.WriteLine("{0}\t{1}\t{2}",process.Id,process.Memory,process.Name);
            }
        }

        static void Main()
        {
            DisplayProcesses();
            Console.Read();
        }
    }
}
