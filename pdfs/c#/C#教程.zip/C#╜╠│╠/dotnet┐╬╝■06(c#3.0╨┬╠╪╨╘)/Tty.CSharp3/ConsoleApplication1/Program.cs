﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Test(Predicate<int> m)
        {
            int i=5;
            if (m(i))
            {
                Console.WriteLine("Yes");
            }
            else
            {
                Console.WriteLine("No");
            }
        }

        static void Main(string[] args)
        {
            Test(x=>x==5);
            Console.Read();
        }
    }
}
