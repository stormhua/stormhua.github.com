﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Tty.CSharp3.Two
{
    public class Program
    {
        public class ProcessData
        {
            public int Id { get; set; }

            public long Memory { get; set; }

            public string Name { get; set; }
        }

        static void DisplayProcesses()
        {
            List<ProcessData> processes = new List<ProcessData>();
            foreach (Process process in Process.GetProcesses())
            {
                ProcessData data = new ProcessData();
                data.Id = process.Id;
                data.Name = process.ProcessName;
                data.Memory = process.WorkingSet64;
                processes.Add(data);
            }

            Display(processes);
        }

        static void Display(List<ProcessData> processes)
        {
            foreach (ProcessData process in processes)
            {
                Console.WriteLine("{0}\t{1}\t{2}", process.Id, process.Memory, process.Name);
            }
        }

        static void Main()
        {
            DisplayProcesses();
            Console.Read();
        }
    }
}
