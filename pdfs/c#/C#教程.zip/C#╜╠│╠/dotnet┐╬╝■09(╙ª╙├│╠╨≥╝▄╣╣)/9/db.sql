if exists (select * from sysobjects where id = OBJECT_ID('[Courses]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [Courses]

CREATE TABLE [Courses] (
[ID] [int]  IDENTITY (1, 1)  NOT NULL,
[Number] [varchar]  (10) NULL,
[Name] [varchar]  (50) NULL,
[Period] [int]  NULL,
[CreditHour] [float]  NULL)

ALTER TABLE [Courses] WITH NOCHECK ADD  CONSTRAINT [PK_Courses] PRIMARY KEY  NONCLUSTERED ( [ID] )
SET IDENTITY_INSERT [Courses] ON


SET IDENTITY_INSERT [Courses] OFF
if exists (select * from sysobjects where id = OBJECT_ID('[Scores]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [Scores]

CREATE TABLE [Scores] (
[ID] [int]  IDENTITY (1, 1)  NOT NULL,
[StudentID] [int]  NULL,
[CourseID] [int]  NULL,
[Score] [int]  NULL)

ALTER TABLE [Scores] WITH NOCHECK ADD  CONSTRAINT [PK_Scores] PRIMARY KEY  NONCLUSTERED ( [ID] )
SET IDENTITY_INSERT [Scores] ON


SET IDENTITY_INSERT [Scores] OFF
if exists (select * from sysobjects where id = OBJECT_ID('[Students]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [Students]

CREATE TABLE [Students] (
[ID] [int]  IDENTITY (1, 1)  NOT NULL,
[Number] [varchar]  (10) NULL,
[Name] [varchar]  (10) NULL,
[Sex] [varchar]  (2) NULL,
[Department] [varchar]  (50) NULL,
[Grade] [varchar]  (15) NULL)

ALTER TABLE [Students] WITH NOCHECK ADD  CONSTRAINT [PK_Students] PRIMARY KEY  NONCLUSTERED ( [ID] )
SET IDENTITY_INSERT [Students] ON


SET IDENTITY_INSERT [Students] OFF
if exists (select * from sysobjects where id = OBJECT_ID('[Teachers]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [Teachers]

CREATE TABLE [Teachers] (
[ID] [int]  IDENTITY (1, 1)  NOT NULL,
[Number] [varchar]  (10) NULL,
[Name] [varchar]  (10) NULL,
[Sex] [varchar]  (2) NULL,
[JobTitle] [varchar]  (15) NULL,
[Headship] [varchar]  (20) NULL)

ALTER TABLE [Teachers] WITH NOCHECK ADD  CONSTRAINT [PK_Teachers] PRIMARY KEY  NONCLUSTERED ( [ID] )
SET IDENTITY_INSERT [Teachers] ON

INSERT [Teachers] ([ID],[Number],[Name],[Sex],[JobTitle],[Headship]) VALUES ( 1,'0001','����','��','����','ϵ���')
INSERT [Teachers] ([ID],[Number],[Name],[Sex],[JobTitle]) VALUES ( 2,'0002','����','��','����')
INSERT [Teachers] ([ID],[Number],[Name],[Sex],[JobTitle],[Headship]) VALUES ( 4,'0004','��С��','Ů','��ʦ','ʵ��������')
INSERT [Teachers] ([ID],[Number],[Name],[Sex],[JobTitle],[Headship]) VALUES ( 5,'0005','���»�','��','�߹�','����������')
INSERT [Teachers] ([ID],[Number],[Name],[Sex],[JobTitle],[Headship]) VALUES ( 6,'0006','��С��','��','��ʦ','����������')

SET IDENTITY_INSERT [Teachers] OFF
if exists (select * from sysobjects where id = OBJECT_ID('[TeachingMission]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [TeachingMission]

CREATE TABLE [TeachingMission] (
[ID] [int]  NOT NULL,
[TeacherID] [int]  NULL,
[CourseID] [int]  NULL)

ALTER TABLE [TeachingMission] WITH NOCHECK ADD  CONSTRAINT [PK_TeachingMission] PRIMARY KEY  NONCLUSTERED ( [ID] )
