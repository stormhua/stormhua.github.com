using System;
using System.Data;
using System.Collections.Generic;
using LTP.Common;
using TeachingManageSystem.Model;
namespace TeachingManageSystem.BLL
{
	/// <summary>
	/// ҵ���߼���Scores ��ժҪ˵����
	/// </summary>
	public class Scores
	{
		private readonly TeachingManageSystem.DAL.Scores dal=new TeachingManageSystem.DAL.Scores();
		public Scores()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
			return dal.GetMaxId();
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int ID)
		{
			return dal.Exists(ID);
		}

		/// <summary>
		/// ����һ������
		/// </summary>
		public int  Add(TeachingManageSystem.Model.Scores model)
		{
			return dal.Add(model);
		}

		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(TeachingManageSystem.Model.Scores model)
		{
			dal.Update(model);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int ID)
		{
			
			dal.Delete(ID);
		}

		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public TeachingManageSystem.Model.Scores GetModel(int ID)
		{
			
			return dal.GetModel(ID);
		}

		/// <summary>
		/// �õ�һ������ʵ�壬�ӻ����С�
		/// </summary>
		public TeachingManageSystem.Model.Scores GetModelByCache(int ID)
		{
			
			string CacheKey = "ScoresModel-" + ID;
			object objModel = LTP.Common.DataCache.GetCache(CacheKey);
			if (objModel == null)
			{
				try
				{
					objModel = dal.GetModel(ID);
					if (objModel != null)
					{
						int ModelCache = LTP.Common.ConfigHelper.GetConfigInt("ModelCache");
						LTP.Common.DataCache.SetCache(CacheKey, objModel, DateTime.Now.AddMinutes(ModelCache), TimeSpan.Zero);
					}
				}
				catch{}
			}
			return (TeachingManageSystem.Model.Scores)objModel;
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			return dal.GetList(strWhere);
		}
		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			return dal.GetList(Top,strWhere,filedOrder);
		}
		/// <summary>
		/// ��������б�
		/// </summary>
		public List<TeachingManageSystem.Model.Scores> GetModelList(string strWhere)
		{
			DataSet ds = dal.GetList(strWhere);
			return DataTableToList(ds.Tables[0]);
		}
		/// <summary>
		/// ��������б�
		/// </summary>
		public List<TeachingManageSystem.Model.Scores> DataTableToList(DataTable dt)
		{
			List<TeachingManageSystem.Model.Scores> modelList = new List<TeachingManageSystem.Model.Scores>();
			int rowsCount = dt.Rows.Count;
			if (rowsCount > 0)
			{
				TeachingManageSystem.Model.Scores model;
				for (int n = 0; n < rowsCount; n++)
				{
					model = new TeachingManageSystem.Model.Scores();
					if(dt.Rows[n]["ID"].ToString()!="")
					{
						model.ID=int.Parse(dt.Rows[n]["ID"].ToString());
					}
					if(dt.Rows[n]["StudentID"].ToString()!="")
					{
						model.StudentID=int.Parse(dt.Rows[n]["StudentID"].ToString());
					}
					if(dt.Rows[n]["CourseID"].ToString()!="")
					{
						model.CourseID=int.Parse(dt.Rows[n]["CourseID"].ToString());
					}
					if(dt.Rows[n]["Score"].ToString()!="")
					{
						model.Score=int.Parse(dt.Rows[n]["Score"].ToString());
					}
					modelList.Add(model);
				}
			}
			return modelList;
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetAllList()
		{
			return GetList("");
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		//public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		//{
			//return dal.GetList(PageSize,PageIndex,strWhere);
		//}

		#endregion  ��Ա����
	}
}

