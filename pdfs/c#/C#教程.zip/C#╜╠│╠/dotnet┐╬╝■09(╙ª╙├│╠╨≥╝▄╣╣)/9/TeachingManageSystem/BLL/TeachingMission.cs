using System;
using System.Data;
using System.Collections.Generic;
using LTP.Common;
using TeachingManageSystem.Model;
namespace TeachingManageSystem.BLL
{
	/// <summary>
	/// ҵ���߼���TeachingMission ��ժҪ˵����
	/// </summary>
	public class TeachingMission
	{
		private readonly TeachingManageSystem.DAL.TeachingMission dal=new TeachingManageSystem.DAL.TeachingMission();
		public TeachingMission()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
			return dal.GetMaxId();
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int ID)
		{
			return dal.Exists(ID);
		}

		/// <summary>
		/// ����һ������
		/// </summary>
		public void Add(TeachingManageSystem.Model.TeachingMission model)
		{
			dal.Add(model);
		}

		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(TeachingManageSystem.Model.TeachingMission model)
		{
			dal.Update(model);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int ID)
		{
			
			dal.Delete(ID);
		}

		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public TeachingManageSystem.Model.TeachingMission GetModel(int ID)
		{
			
			return dal.GetModel(ID);
		}

		/// <summary>
		/// �õ�һ������ʵ�壬�ӻ����С�
		/// </summary>
		public TeachingManageSystem.Model.TeachingMission GetModelByCache(int ID)
		{
			
			string CacheKey = "TeachingMissionModel-" + ID;
			object objModel = LTP.Common.DataCache.GetCache(CacheKey);
			if (objModel == null)
			{
				try
				{
					objModel = dal.GetModel(ID);
					if (objModel != null)
					{
						int ModelCache = LTP.Common.ConfigHelper.GetConfigInt("ModelCache");
						LTP.Common.DataCache.SetCache(CacheKey, objModel, DateTime.Now.AddMinutes(ModelCache), TimeSpan.Zero);
					}
				}
				catch{}
			}
			return (TeachingManageSystem.Model.TeachingMission)objModel;
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			return dal.GetList(strWhere);
		}
		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			return dal.GetList(Top,strWhere,filedOrder);
		}
		/// <summary>
		/// ��������б�
		/// </summary>
		public List<TeachingManageSystem.Model.TeachingMission> GetModelList(string strWhere)
		{
			DataSet ds = dal.GetList(strWhere);
			return DataTableToList(ds.Tables[0]);
		}
		/// <summary>
		/// ��������б�
		/// </summary>
		public List<TeachingManageSystem.Model.TeachingMission> DataTableToList(DataTable dt)
		{
			List<TeachingManageSystem.Model.TeachingMission> modelList = new List<TeachingManageSystem.Model.TeachingMission>();
			int rowsCount = dt.Rows.Count;
			if (rowsCount > 0)
			{
				TeachingManageSystem.Model.TeachingMission model;
				for (int n = 0; n < rowsCount; n++)
				{
					model = new TeachingManageSystem.Model.TeachingMission();
					if(dt.Rows[n]["ID"].ToString()!="")
					{
						model.ID=int.Parse(dt.Rows[n]["ID"].ToString());
					}
					if(dt.Rows[n]["TeacherID"].ToString()!="")
					{
						model.TeacherID=int.Parse(dt.Rows[n]["TeacherID"].ToString());
					}
					if(dt.Rows[n]["CourseID"].ToString()!="")
					{
						model.CourseID=int.Parse(dt.Rows[n]["CourseID"].ToString());
					}
					modelList.Add(model);
				}
			}
			return modelList;
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetAllList()
		{
			return GetList("");
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		//public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		//{
			//return dal.GetList(PageSize,PageIndex,strWhere);
		//}

		#endregion  ��Ա����
	}
}

