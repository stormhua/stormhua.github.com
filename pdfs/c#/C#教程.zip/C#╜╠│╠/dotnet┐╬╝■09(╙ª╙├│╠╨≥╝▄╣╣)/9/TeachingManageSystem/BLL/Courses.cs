using System;
using System.Data;
using System.Collections.Generic;
using LTP.Common;
using TeachingManageSystem.Model;
namespace TeachingManageSystem.BLL
{
	/// <summary>
	/// ҵ���߼���Courses ��ժҪ˵����
	/// </summary>
	public class Courses
	{
		private readonly TeachingManageSystem.DAL.Courses dal=new TeachingManageSystem.DAL.Courses();
		public Courses()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
			return dal.GetMaxId();
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int ID)
		{
			return dal.Exists(ID);
		}

		/// <summary>
		/// ����һ������
		/// </summary>
		public int  Add(TeachingManageSystem.Model.Courses model)
		{
			return dal.Add(model);
		}

		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(TeachingManageSystem.Model.Courses model)
		{
			dal.Update(model);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int ID)
		{
			
			dal.Delete(ID);
		}

		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public TeachingManageSystem.Model.Courses GetModel(int ID)
		{
			
			return dal.GetModel(ID);
		}

		/// <summary>
		/// �õ�һ������ʵ�壬�ӻ����С�
		/// </summary>
		public TeachingManageSystem.Model.Courses GetModelByCache(int ID)
		{
			
			string CacheKey = "CoursesModel-" + ID;
			object objModel = LTP.Common.DataCache.GetCache(CacheKey);
			if (objModel == null)
			{
				try
				{
					objModel = dal.GetModel(ID);
					if (objModel != null)
					{
						int ModelCache = LTP.Common.ConfigHelper.GetConfigInt("ModelCache");
						LTP.Common.DataCache.SetCache(CacheKey, objModel, DateTime.Now.AddMinutes(ModelCache), TimeSpan.Zero);
					}
				}
				catch{}
			}
			return (TeachingManageSystem.Model.Courses)objModel;
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			return dal.GetList(strWhere);
		}
		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			return dal.GetList(Top,strWhere,filedOrder);
		}
		/// <summary>
		/// ��������б�
		/// </summary>
		public List<TeachingManageSystem.Model.Courses> GetModelList(string strWhere)
		{
			DataSet ds = dal.GetList(strWhere);
			return DataTableToList(ds.Tables[0]);
		}
		/// <summary>
		/// ��������б�
		/// </summary>
		public List<TeachingManageSystem.Model.Courses> DataTableToList(DataTable dt)
		{
			List<TeachingManageSystem.Model.Courses> modelList = new List<TeachingManageSystem.Model.Courses>();
			int rowsCount = dt.Rows.Count;
			if (rowsCount > 0)
			{
				TeachingManageSystem.Model.Courses model;
				for (int n = 0; n < rowsCount; n++)
				{
					model = new TeachingManageSystem.Model.Courses();
					if(dt.Rows[n]["ID"].ToString()!="")
					{
						model.ID=int.Parse(dt.Rows[n]["ID"].ToString());
					}
					model.Number=dt.Rows[n]["Number"].ToString();
					model.Name=dt.Rows[n]["Name"].ToString();
					if(dt.Rows[n]["Period"].ToString()!="")
					{
						model.Period=int.Parse(dt.Rows[n]["Period"].ToString());
					}
					if(dt.Rows[n]["CreditHour"].ToString()!="")
					{
						model.CreditHour=decimal.Parse(dt.Rows[n]["CreditHour"].ToString());
					}
					modelList.Add(model);
				}
			}
			return modelList;
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetAllList()
		{
			return GetList("");
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		//public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		//{
			//return dal.GetList(PageSize,PageIndex,strWhere);
		//}

		#endregion  ��Ա����
	}
}

