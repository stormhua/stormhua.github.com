using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachingManageSystem.BLL;

namespace TeachManageSystem
{
    public partial class StudentFrm : Form
    {
        public StudentFrm()
        {
            InitializeComponent();
        }

        private void tsbQuery_Click(object sender, EventArgs e)
        {
            
        }
    }
}