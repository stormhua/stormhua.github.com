using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachingManageSystem.BLL;
using TeachingManageSystem.Model;

namespace TeachManageSystem
{
    public partial class TeacherFrm : Form
    {
        /// <summary>
        /// ��Ų�ѯ�õ��ļ�¼��
        /// </summary>
        private IList<TeachingManageSystem.Model.Teachers> _teachersInfo = null;
        private TeachingManageSystem.BLL.Teachers _bll = new TeachingManageSystem.BLL.Teachers();

        /// <summary>
        /// ���SQL���
        /// </summary>
        private string _sqlWhere = "id > 0";

        /// <summary>
        /// Ĭ�ϵĹ��캯��
        /// </summary>
        public TeacherFrm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// ��������ʱִ�еĳ�ʼ������
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TeacherFrm_Load(object sender, EventArgs e)
        {
            //һЩ�ؼ��ĳ�ʼ��
            AdjustColumnOrder();//DataGridView�ؼ����ֶ�����˳��
            cbQueryField.SelectedIndex = 0;//���ò�ѯ����Ĭ��ֵ
            tvJobTitle.ExpandAll();//չ�����ؼ�

            //��ʾ���н�ʦ������
            Query();
        }

        /// <summary>
        /// DataGridView�ؼ����ֶ�����˳��
        /// </summary>
        private void AdjustColumnOrder()
        {
            dgvTeacher.Columns["ColumnID"].Visible = false;
            dgvTeacher.Columns["ColumnNumber"].DisplayIndex = 0;
            dgvTeacher.Columns["ColumnName"].DisplayIndex = 1;
            dgvTeacher.Columns["ColumnSex"].DisplayIndex = 2;
            dgvTeacher.Columns["ColumnJobTitle"].DisplayIndex = 3;
            dgvTeacher.Columns["ColumnHeadship"].DisplayIndex = 4;
        }

        /// <summary>
        /// ִ�в�ѯ
        /// </summary>
        private void tsbQuery_Click(object sender, EventArgs e)
        {
            CreateSQL(cbQueryField.Text, tbQueryKey.Text, rbExact.Checked);
            Query();
        }

        /// <summary>
        /// ���ɲ�ѯ����
        /// </summary>
        /// <param name="field">��ѯ�ֶ�</param>
        /// <param name="value">��ѯ�ؼ���</param>
        /// <param name="isExact">�Ǿ�ȷ��ѯ��</param>
        private void CreateSQL(string field,string value,bool isExact)
        {
            switch (field)
            {
                case "����":
                    _sqlWhere = string.Format(isExact ? "Number = '{0}'" : "Number like '%{0}%'", value);
                    break;
                case "����":
                    _sqlWhere = string.Format(isExact ? "Name = '{0}'" : "Name like '%{0}%'", value);
                    break;
                case "�Ա�":
                    _sqlWhere = string.Format(isExact ? "Sex = '{0}'" : "Sex like '%{0}%'", value);
                    break;
                case "ְ��":
                    _sqlWhere = string.Format(isExact ? "JobTitle = '{0}'" : "JobTitle like '%{0}%'", value);
                    break;
                case "ְ��":
                    _sqlWhere = string.Format(isExact ? "Headship = '{0}'" : "Headship like '%{0}%'", value);
                    break;
                default:
                    _sqlWhere = "id > 0"; //�������ѯ�������Բ鴦ȫ����¼��id��Զ����0��
                    break;
            }
        }

        /// <summary>
        /// ��ʾ��ѯ�Ľṹ��������
        /// </summary>
        private void Display()
        {
            ssCount.Items["tsslCount"].Text = _teachersInfo.Count.ToString();//���鵽�ļ�¼������
            dgvTeacher.DataSource = _teachersInfo;//����ѯ�Ľṹ��ʾ��DataGridView�ؼ�
        }

        /// <summary>
        /// ��װ�Ĳ�ѯ����
        /// </summary>
        private void Query()
        {
            _teachersInfo = _bll.GetModelList(_sqlWhere);
            Display();
        }

        /// <summary>
        /// ѡ�����ؼ��Ľڵ�������¼�
        /// </summary>
        private void tvJobTitle_AfterSelect(object sender, TreeViewEventArgs e)
        {
            CreateSQL("ְ��", tvJobTitle.SelectedNode.Text, true);
            Query();
        }

        /// <summary>
        /// ����
        /// </summary>
        private void tsbAdd_Click(object sender, EventArgs e)
        {
            TeacherInfoFrm form = new TeacherInfoFrm();
            form.ShowDialog();
            Query();
        }

        /// <summary>
        /// �޸�
        /// </summary>
        private void tsbUpdate_Click(object sender, EventArgs e)
        {
            TeacherInfoFrm form = new TeacherInfoFrm(dgvTeacher.SelectedRows[0].DataBoundItem as TeachingManageSystem.Model.Teachers);
            form.ShowDialog();
            Query();
        }

        /// <summary>
        /// ɾ��
        /// </summary>
        private void tsbDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("ȷ��ɾ����", "��ʾ", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    string message = "ɾ���ɹ���";
                    _bll.Delete(_teachersInfo[dgvTeacher.SelectedRows[0].Index].ID);
                    MessageBox.Show(message);
                    Query();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// ˢ��
        /// </summary>
        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            Query();
        }

        /// <summary>
        /// �˳���ʦ���Ϲ�������
        /// </summary>
        private void tsbExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}