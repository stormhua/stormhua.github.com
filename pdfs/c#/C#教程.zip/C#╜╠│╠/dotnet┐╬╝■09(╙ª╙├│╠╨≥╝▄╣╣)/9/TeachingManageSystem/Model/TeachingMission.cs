using System;
namespace TeachingManageSystem.Model
{
	/// <summary>
	/// ʵ����TeachingMission ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class TeachingMission
	{
		public TeachingMission()
		{}
		#region Model
		private int _id;
		private int? _teacherid;
		private int? _courseid;
		/// <summary>
		/// ����
		/// </summary>
		public int ID
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// ��ʦID
		/// </summary>
		public int? TeacherID
		{
			set{ _teacherid=value;}
			get{return _teacherid;}
		}
		/// <summary>
		/// �γ�ID
		/// </summary>
		public int? CourseID
		{
			set{ _courseid=value;}
			get{return _courseid;}
		}
		#endregion Model

	}
}

