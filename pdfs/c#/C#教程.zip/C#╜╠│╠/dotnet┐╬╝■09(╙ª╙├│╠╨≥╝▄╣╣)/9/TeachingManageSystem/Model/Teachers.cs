using System;
namespace TeachingManageSystem.Model
{
	/// <summary>
	/// ʵ����Teachers ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class Teachers
	{
		public Teachers()
		{}
		#region Model
		private int _id;
		private string _number;
		private string _name;
		private string _sex;
		private string _jobtitle;
		private string _headship;
		/// <summary>
		/// ����
		/// </summary>
		public int ID
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// ����
		/// </summary>
		public string Number
		{
			set{ _number=value;}
			get{return _number;}
		}
		/// <summary>
		/// ����
		/// </summary>
		public string Name
		{
			set{ _name=value;}
			get{return _name;}
		}
		/// <summary>
		/// �Ա�
		/// </summary>
		public string Sex
		{
			set{ _sex=value;}
			get{return _sex;}
		}
		/// <summary>
		/// ְ��
		/// </summary>
		public string JobTitle
		{
			set{ _jobtitle=value;}
			get{return _jobtitle;}
		}
		/// <summary>
		/// ְ��
		/// </summary>
		public string Headship
		{
			set{ _headship=value;}
			get{return _headship;}
		}
		#endregion Model

	}
}

