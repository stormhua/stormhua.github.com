using System;
namespace TeachingManageSystem.Model
{
	/// <summary>
	/// ʵ����Courses ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class Courses
	{
		public Courses()
		{}
		#region Model
		private int _id;
		private string _number;
		private string _name;
		private int? _period;
		private decimal? _credithour;
		/// <summary>
		/// ����
		/// </summary>
		public int ID
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// �γ̺�
		/// </summary>
		public string Number
		{
			set{ _number=value;}
			get{return _number;}
		}
		/// <summary>
		/// �γ���
		/// </summary>
		public string Name
		{
			set{ _name=value;}
			get{return _name;}
		}
		/// <summary>
		/// ѧʱ
		/// </summary>
		public int? Period
		{
			set{ _period=value;}
			get{return _period;}
		}
		/// <summary>
		/// ѧ��
		/// </summary>
		public decimal? CreditHour
		{
			set{ _credithour=value;}
			get{return _credithour;}
		}
		#endregion Model

	}
}

