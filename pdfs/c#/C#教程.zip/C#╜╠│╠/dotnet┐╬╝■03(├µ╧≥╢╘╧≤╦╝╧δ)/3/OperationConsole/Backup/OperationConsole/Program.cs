﻿using System;
using System.Collections.Generic;
using System.Text;
using Operation;

namespace OperationConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //读入操作数和操作符
                Console.Write("请输入数字A：");
                string strNumberA = Console.ReadLine();
                Console.Write("请选择运算符号(Add、Sub、Mul、Div、Sqrt、Mul2)：");
                string strOperate = Console.ReadLine();
                Console.Write("请输入数字B：");
                string strNumberB = Console.ReadLine();

                //进行计算
                Operation.Operation oper;
                oper = OperationFactory.createOperate(strOperate);
                oper.NumberA = Convert.ToDouble(strNumberA);
                oper.NumberB = Convert.ToDouble(strNumberB);
                double result = oper.GetResult();
                Console.WriteLine(result.ToString());
                Console.Read();

            }
            catch
            {
                Console.Read();
            }
        }
    }
}
