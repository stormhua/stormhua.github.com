namespace Operation
{
    public class OperationMul3 : Operation
    {
        public override double GetResult()
        {
            return NumberA*NumberA*NumberA;
        }
    }
}