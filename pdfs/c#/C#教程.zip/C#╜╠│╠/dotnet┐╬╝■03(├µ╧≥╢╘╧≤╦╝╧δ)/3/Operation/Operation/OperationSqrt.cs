using System;
using System.Collections.Generic;
using System.Text;

namespace Operation
{
    public class OperationSqrt:Operation
    {
        public override double GetResult()
        {
            double result = 0;
            result = Math.Sqrt(NumberA);
            return result;
        }
    }
}
