$.fn.checkall = function(group) {
	$(this).click(function(){
	     var checked = $(this).attr("checked");
	     $("input[name='"+group+"']").each(function(){
		$(this).attr("checked",checked);
	     });
	});
};