﻿// JScript 文件
//$(function(){
//  $("#checkall").click( function(){
//     var checked = $(this).attr("checked");
//     $("table td input:checkbox").each(function(){
//        this.checked = checked;
//     });
//  });
//});
$(function(){
   $('#checkall').check("test");
});


