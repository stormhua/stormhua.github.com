﻿// JScript 文件
$.fn.check = function(group) {
	return this.each(function() {
	    $(this).click(function(){
	        var checked = $(this).attr("checked");
		    $("input[name='"+group+"']").each(function(){
		        $(this).attr("checked",checked);
		    });
		});
	});
};

