﻿

$(document).ready(function() { 
     $("#orderedlist").addClass("red"); 
}); 

$(document).ready(function() {
	$("#orderedlist li:last").hover(function() {
		$(this).addClass("green");
	}, function() {
		$(this).removeClass("green");
	});
});

$(document).ready(function() { 
       $("#orderedlist").find("li").each(function(i) { 
                    $(this).html( 
                                          $(this).html() + " BAM! " + i 
                                                       ); 
                                                              }); 
                                                              }); 
                                                              

$(document).ready(function() {
	// use this to reset a single form
	$("#reset").click(function() {
		$("#form")[0].reset();
	});
});

$(document).ready(function() { 
     $("li").not(":has(ul)").css("border", "1px solid black");
}); 

 
$(document).ready(function() { 
      $('#faq').find('dd').hide().end().find('dt').click(function() { 
               var answer = $(this).next(); 
               if (answer.is(':visible')) { 
                       answer.slideUp(); 
               } 
               else { 
                       answer.slideDown(); 
               } 
     }); 
});

$(document).ready(function() { 
      $("a").hover(function() { 
            $(this).parents("p").addClass("highlight"); 
       }, 
       function() { 
            $(this).parents("p").removeClass("highlight"); 
       }); 
}); 

$(document).ready(function() { 
      $("a").toggle(function() { 
            $(".stuff").hide('slow'); 
      }, function() { 
            $(".stuff").show('fast'); 
     }); 
}); 

$(document).ready(function() {
	$("#large").tableSorter();
});



$(document).ready(function() {
	$("#large").tableSorter({
		stripingRowClass: ['odd','even'],	// Class names for striping supplyed as a array.
		stripRowsOnStartUp: true		// Strip rows on tableSorter init.
	});
});

$(function(){
    var s = "{stripingRowClass: ['odd','even'], stripRowsOnStartUp: true}";
    
    alert(j.stripingRowClass[1]);

});

