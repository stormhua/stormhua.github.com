﻿



$(document).ready(function() { 
     $("#orderedlist > li").addClass("blue"); 
});

$(document).ready(function() { 
     $("#orderedlist li:last").hover(function() { 
           $(this).addClass("green"); 
     }, function() { 
           $(this).removeClass("green"); 
     }); 
}); 

$(document).ready(function() { 
       $("#orderedlist").find("li").each(function(i) {
             $(this).html(
                      $(this).html() + " BAM! " + i 
             ); 
       }); 
}); 



$(document).ready(function() {
     $("#reset").click(function(){
         $("form").each(function(){
             this.reset();
         });
     });
});

$(document).ready(function() { 
     $("li").not(":has(ul)")
     //$("li").not("[ul]") 
             .css("border", "1px solid black");
}); 

$(document).ready(function() { 
      $("a[name]").css("background-color","#000"); 
}); 

$(document).ready(function() { 
      $('#faq').find('dd').hide();
      $('#faq').find('dt').click(function() { 
               var answer = $(this).next(); 
               if (answer.is(':visible')) { 
                       answer.slideUp(); 
               } 
               else { 
                       answer.slideDown(); 
               } 
     }); 
}); 
     
$(function() { 
      $("a").hover(function() { 
            $(this).parents("p").addClass("highlight"); 
       }, function() { 
            $(this).parents("p").removeClass("highlight"); 
       }); 
}); 

$(document).ready(function() { 
      $("a").toggle(function() { 
             $(".stuff").animate({ 
                   height: 'hide', opacity: 'hide' 
             }, 'slow'); 
      }, function() { 
             $(".stuff").animate({ 
                   height: 'show', opacity: 'show' 
             }, 'slow'); 
      }); 
}); 

$(document).ready(function() { 
        $("#large").tableSorter(); 
}); 
