﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _4_2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Write("<script language='javascript'>alert('服务器端按钮执行客户端JavaScript代码');</script>");        
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        RegisterStartupScript("", "<script language='javascript'>alert('服务器端按钮执行客户端JavaScript代码');</script>");
    }
}
