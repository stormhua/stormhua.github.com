﻿// JScript 文件

document.write("Hello Word!");