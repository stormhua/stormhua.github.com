﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _5_6 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Button1.OnClientClick = string.Format("var result=isIP( document.getElementById('{0}').value); if(!result) alert('“'+document.getElementById('{0}').value+'”不符合IP地址格式'); return result;", TextBox1.ClientID);
            Button2.OnClientClick = string.Format("var result=isInteger( document.getElementById('{0}').value); if(!result) alert('“'+document.getElementById('{0}').value+'”不符合整型格式'); return result;", TextBox2.ClientID);
            Button3.OnClientClick = string.Format("var result=checkMobile( document.getElementById('{0}').value); if(!result) alert('“'+document.getElementById('{0}').value+'”不符合手机号码格式'); return result;", TextBox3.ClientID);
            Button4.OnClientClick = string.Format("var result=checkEmail( document.getElementById('{0}').value); return result;", TextBox4.ClientID);
            Button5.OnClientClick = string.Format("var result=isDate( document.getElementById('{0}').value,'yyyy-MM-dd'); if(!result) alert('“'+document.getElementById('{0}').value+'”不符合日期格式'); return result;", TextBox5.ClientID);
        }
    }
}
