﻿using System;
using NunitDemo;
using NUnit.Framework;

namespace NUnitDemo.Test
{

    [TestFixture]
    public class TestLargest
    {
        [Test]
        public void LargestOf3()
        {
            Assert.AreEqual(9, Cmp.Largest(new int[] { 8, 9, 7 }));
            Assert.AreEqual(9, Cmp.Largest(new int[] { 9, 8, 7 }));
            Assert.AreEqual(9, Cmp.Largest(new int[] { 7, 8, 9 }));
        }

        [Test]
        public void TestDups()
        {
            Assert.AreEqual(9, Cmp.Largest(new int[] { 9, 7, 9, 8 }));
        }

        [Test]
        public void TestOne()
        {
            Assert.AreEqual(1, Cmp.Largest(new int[] { 1 }));
        }

        [Test]
        public void TestNegative()
        {
            Assert.AreEqual(-7, Cmp.Largest(new int[] { -9, -8, -7 }));
        }

        [Test,ExpectedException(typeof(ArgumentException))]
        public void TestEmpty( )
        {
            Cmp.Largest(new int[] {});
        }
    }
}
