﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NunitDemo
{
    public class Cmp
    {
        public static int Largest(int[] list)
        {
            int max = Int32.MinValue;
            if( list.Length==0 )
                throw new ArgumentException("Largest: Empty list.");
            for (int i = 0; i <= list.Length - 1; i++)
            {
                max = list[i] > max ? list[i] : max;
            }
            return max;
        }
    }
}
