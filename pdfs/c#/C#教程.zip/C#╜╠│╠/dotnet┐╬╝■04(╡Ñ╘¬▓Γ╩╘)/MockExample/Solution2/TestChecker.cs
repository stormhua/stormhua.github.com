using System;
using NUnit.Framework;
using NUnit.Mocks;

namespace Solution2
{
    [TestFixture]
    public class TestChecker
    {
        [Test]
        public void QuittingTime()
        {
            DateTime when = new DateTime(2012, 1, 1, 16, 55, 0);
            DynamicMock env = new DynamicMock(typeof(IEnvironment));
            env.SetReturnValue("Now", when);
            Checker checker = new Checker(env.MockInstance as IEnvironment);

            // 16:55��������������
            checker.Reminder();
            Assert.IsFalse(checker.CheckAndResetSound(), "16:55");

            // 17:00
            when = when.AddMinutes(5);
            env.SetReturnValue("Now", when);
            checker.Reminder();
            Assert.IsTrue(checker.CheckAndResetSound(), "17:00");

            // 19:00
            when = when.AddMinutes(120);
            env.SetReturnValue("Now", when);
            checker.Reminder();
            Assert.IsTrue(checker.CheckAndResetSound(), "19:00");
        }
    }
}