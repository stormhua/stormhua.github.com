using System;

namespace Solution2
{
    public class Checker
    {
        private IEnvironment env;
        private bool soundWasPlayed = false;

        public Checker(IEnvironment env)
        {
            this.env = env;
        }

        public void Reminder()
        {
            DateTime now = env.Now();

            if (now.Hour >= 17)
            {
                env.PlayWavFile("quit_whistle.wav");
                soundWasPlayed = true;
            }
        }

        public bool CheckAndResetSound()
        {
            bool value = soundWasPlayed;
            soundWasPlayed = false;
            return value;
        }
    }
}