using System;

namespace Solution2
{
    public interface IEnvironment
    {
        DateTime Now();
        void PlayWavFile(string fileName);
    }
}