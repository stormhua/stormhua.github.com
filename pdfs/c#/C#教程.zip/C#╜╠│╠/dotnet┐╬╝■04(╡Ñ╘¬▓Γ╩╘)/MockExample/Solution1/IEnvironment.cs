using System;

namespace Solution1
{
    public interface IEnvironment
    {
        DateTime Now { get; }
        void PlayWavFile(string fileName);
    }
}