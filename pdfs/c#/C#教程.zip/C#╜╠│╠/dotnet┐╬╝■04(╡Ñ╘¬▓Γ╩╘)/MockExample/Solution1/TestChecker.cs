using System;
using NUnit.Framework;

namespace Solution1
{
    [TestFixture]
    public class TestChecker
    {
        [Test]
        public void QuittingTime()
        {
            DateTime when = new DateTime(2012,1,1,16,55,0);
            MockSystemEnvironment env = new MockSystemEnvironment(when);
            Checker checker = new Checker(env);

            // 16:55��������������
            checker.Reminder();
            Assert.IsFalse(checker.CheckAndResetSound(), "16:55");

            // 17:00
            env.IncrementMinutes(5);
            checker.Reminder();
            Assert.IsTrue(checker.CheckAndResetSound(), "17:00");

            // 19:00
            env.IncrementMinutes(120);
            checker.Reminder();
            Assert.IsTrue(checker.CheckAndResetSound(), "19:00");
        }
    }
}