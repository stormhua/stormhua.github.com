using System;

namespace Solution1
{
    public class MockSystemEnvironment : IEnvironment
    {
        private DateTime _currentTime;

        public MockSystemEnvironment(DateTime when)
        {
            _currentTime = when;
        }

        public DateTime Now
        {
            get { return _currentTime; }
        }

        public void PlayWavFile(string fileName)
        {
            
        }

        public void IncrementMinutes(int minutes)
        {
            _currentTime = _currentTime.AddMinutes(minutes);
        }
    }
}