﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection myCon = new SqlConnection("Data Source=.\\SQL2000;Initial Catalog=Northwind;Integrated Security=True");
            myCon.Open();

            StringBuilder sb = new StringBuilder();

            sb.Append("SELECT dbo.Customers.CustomerID, dbo.Customers.CompanyName, ");
            sb.Append("dbo.[Order Details].OrderID, dbo.[Order Details].UnitPrice,  ");
            sb.Append("dbo.[Order Details].Quantity, dbo.[Order Details].Discount, dbo.Orders.OrderDate,  ");
            sb.Append("dbo.Products.ProductName ");
            sb.Append("FROM dbo.Customers INNER JOIN ");
            sb.Append("dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN ");
            sb.Append("dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID INNER JOIN ");
            sb.Append("dbo.Products ON dbo.[Order Details].ProductID = dbo.Products.ProductID ");

            SqlCommand myCom = new SqlCommand();
            myCom.Connection = myCon;
            myCom.CommandText = sb.ToString();

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = myCom;

            DataSet ds = new DataSet();
            adapter.Fill(ds,"Orders");

            OrderCR1.SetDataSource(ds.Tables["Orders"]);

            crystalReportViewer1.RefreshReport();

            myCon.Close();
        }

        private void btReport_Click(object sender, EventArgs e)
        {
            SqlConnection myCon = new SqlConnection("Data Source=.\\SQL2000;Initial Catalog=Northwind;Integrated Security=True");
            myCon.Open();

            StringBuilder sb = new StringBuilder();

            sb.Append("SELECT dbo.Customers.CustomerID, dbo.Customers.CompanyName, ");
            sb.Append("dbo.[Order Details].OrderID, dbo.[Order Details].UnitPrice,  ");
            sb.Append("dbo.[Order Details].Quantity, dbo.[Order Details].Discount, dbo.Orders.OrderDate,  ");
            sb.Append("dbo.Products.ProductName ");
            sb.Append("FROM dbo.Customers INNER JOIN ");
            sb.Append("dbo.Orders ON dbo.Customers.CustomerID = dbo.Orders.CustomerID INNER JOIN ");
            sb.Append("dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID INNER JOIN ");
            sb.Append("dbo.Products ON dbo.[Order Details].ProductID = dbo.Products.ProductID ");

            SqlCommand myCom = new SqlCommand();
            myCom.Connection = myCon;
            myCom.CommandText = sb.ToString();

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = myCom;

            DataSet ds = new DataSet();
            adapter.Fill(ds, "Orders");

            ds.Tables["Orders"].DefaultView.RowFilter = "OrderID="+tbOrderID.Text;

            OrderCR1.SetDataSource(ds.Tables["Orders"].DefaultView);

            crystalReportViewer1.RefreshReport();

            myCon.Close();
        }
    }
}