﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _12 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            //第一行表头
                TableCellCollection tcHeader = e.Row.Cells;
                tcHeader.Clear();
                tcHeader.Add(new TableHeaderCell());
                //tcHeader[1].Attributes.Add"bgcolor", "Red";
                tcHeader[0].Attributes.Add("colspan", "6"); //跨Column
                tcHeader[0].Text = "全部信息</th></tr><tr align='center'>";

                //第二行表头
                tcHeader.Add(new TableHeaderCell());
                tcHeader[1].Attributes.Add("bgcolor", "DarkSeaGreen");
                tcHeader[1].Text = "身份证号码";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[2].Attributes.Add("bgcolor", "LightSteelBlue");
                tcHeader[2].Attributes.Add("colspan", "2");
                tcHeader[2].Text = "基本信息";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[3].Attributes.Add("bgcolor", "DarkSeaGreen");
                tcHeader[3].Text = "福利";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[4].Attributes.Add("bgcolor", "LightSteelBlue");
                tcHeader[4].Attributes.Add("colspan", "2");
                tcHeader[4].Text = "联系方式</th></tr><tr align='center'>";

                //第三行表头
                tcHeader.Add(new TableHeaderCell());
                tcHeader[5].Attributes.Add("bgcolor", "Khaki");
                tcHeader[5].Text = "身份证号码";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[6].Attributes.Add("bgcolor", "Khaki");
                tcHeader[6].Text = "姓名";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[7].Attributes.Add("bgcolor", "Khaki");
                tcHeader[7].Text = "出生日期";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[8].Attributes.Add("bgcolor", "Khaki");
                tcHeader[8].Text = "薪水";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[9].Attributes.Add("bgcolor", "Khaki");
                tcHeader[9].Text = "家庭住址";
                tcHeader.Add(new TableHeaderCell());
                tcHeader[10].Attributes.Add("bgcolor", "Khaki");
                tcHeader[10].Text = "邮政编码";
        }
    }
}
