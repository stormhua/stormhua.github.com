﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _14 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    private decimal sum = 0m;
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            try
            {
                sum += decimal.Parse(e.Row.Cells[4].Text);
            }
            catch
            {
            }
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[3].Text = "平均薪水：";
            e.Row.Cells[4].Text = (sum / GridView1.Rows.Count).ToString("C");
            e.Row.Cells[5].Text = "总薪水：";
            e.Row.Cells[6].Text = sum.ToString("C");

            //设置单元格文字右对齐
            e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Right;

        }
    }
}
