﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tty.Delegate
{
    class Test
    {
        delegate double Calc(double x);

        public static double Square(double x)
        {
            return x * x;
        }

        public static double Cue(double x)
        {
            return x * x * x;
        }

        static double[] Apply(double[] a, Calc f)
        {
            double[] result = new double[a.Length];
            for (int i = 0; i < a.Length; i++) result[i] = f(a[i]);
            return result;
        }
        
        static void Main(string[] args)
        {
            double[] a = { 0.0, 0.5, 1.0 };
            //C#1.0用法
            double[] results = Apply(a, Cue);
            foreach (double d in results)
            {
                Console.WriteLine(d);
            }
            Console.ReadLine();
        }
    }
}