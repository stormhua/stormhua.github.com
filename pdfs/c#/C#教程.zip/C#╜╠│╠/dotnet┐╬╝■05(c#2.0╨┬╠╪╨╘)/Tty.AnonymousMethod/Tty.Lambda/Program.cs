﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tty.Lambda
{
    class Test
    {
        delegate double Calc(double x);

        static double[] Apply(double[] a, Calc f)
        {
            double[] result = new double[a.Length];
            for (int i = 0; i < a.Length; i++) result[i] = f(a[i]);
            return result;
        }

        static void Main(string[] args)
        {
            double[] a = { 0.0, 0.5, 1.0 };
            //C#3.0用法
            double[] results = Apply(a, x => x*x);
            foreach (double d in results)
            {
                Console.WriteLine(d);
            }
            Console.ReadLine();
        }
    }
}
