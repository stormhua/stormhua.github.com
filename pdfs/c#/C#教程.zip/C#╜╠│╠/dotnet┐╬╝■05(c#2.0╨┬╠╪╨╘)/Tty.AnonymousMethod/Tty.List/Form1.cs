﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tty.List
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<string> _list = new List<string>();

        private void InitData()
        {
            _list.Add("计科07101");
            _list.Add("计科07102");
            _list.Add("计科07103");
            _list.Add("计科08101");
            _list.Add("计科08102");
            _list.Add("计科08103");
            _list.Add("计科09101");
            _list.Add("计科09102");
            _list.Add("计科09103");

            _list.Add("网工07101");
            _list.Add("网工07102");
            _list.Add("网工07103");
            _list.Add("网工08101");
            _list.Add("网工08102");
            _list.Add("网工08103");
            _list.Add("网工09101");
            _list.Add("网工09102");
            _list.Add("网工09103");

            _list.Add("信管07101");
            _list.Add("信管07102");
            _list.Add("信管07103");
            _list.Add("信管08101");
            _list.Add("信管08102");
            _list.Add("信管08103");
            _list.Add("信管09101");
            _list.Add("信管09102");
            _list.Add("信管09103");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitData();
            listBox1.DataSource = _list;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox2.DataSource = _list.FindAll(
                delegate(string item)
                    {
                        return item.Contains(textBox1.Text.Trim());
                    }
                );
        }

    }
}
