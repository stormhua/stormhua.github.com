using System;

namespace Tty.Stack
{
    public class Stack<T>
    {
        private T[] _items;
        private int _top;
        private const int MaxCount = 100;
        
        public Stack()
        {
            _items = new T[MaxCount];
            _top = -1;
        }

        public void Push(T item)
        {
            if(_top>=100)
                throw new IndexOutOfRangeException("ջ����");
            _items[++_top] = item;
        }

        public T Pop()
        {
            if(_top<0)
                throw new IndexOutOfRangeException("ջ�������ݣ�");
            _top--;
            return _items[_top + 1];
        }

        public void PushMultiple(params T[] values)
        {
            foreach(T value in values)
            {
                Push(value);
            }
        }

    }
}