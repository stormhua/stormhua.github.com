
using NUnit.Framework;
using System;

namespace Tty.Stack.Test
{
    [TestFixture]
    public class StackFixture
    {
        private Stack<int> _stack;

        [SetUp]
        public void SetUp()
        {
            _stack = new Stack<int>();
        }

        [Test]
        public void StackTest()
        {
            _stack.Push(5);
            _stack.Push(4);

            Assert.AreEqual(4,_stack.Pop());
            Assert.AreEqual(5,_stack.Pop());
        }

        [Test]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void StackExceptionTest()
        {
            _stack.Pop();
        }

        [Test]
        public void PushMultipleTest()
        {
            _stack.PushMultiple(1, 2, 3);
            Assert.AreEqual(3, _stack.Pop());
            Assert.AreEqual(2, _stack.Pop());
            Assert.AreEqual(1, _stack.Pop());
        }

        [Test]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void StackOverflowTest()
        {
            for( int i=0;i<=100;i++ )
            {
                _stack.Push(i);
            }
        }
    }
}