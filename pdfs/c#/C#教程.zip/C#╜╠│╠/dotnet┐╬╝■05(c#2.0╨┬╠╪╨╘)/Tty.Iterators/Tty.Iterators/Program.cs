﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tty.Iterators
{
    public class DaysOfTheWeek : System.Collections.IEnumerable
    {
        string[] m_Days = { "Sun", "Mon", "Tue", "Wed", "Thr", "Fri", "Sat" };

        public System.Collections.IEnumerator GetEnumerator()
        {
            for (int i = 0; i < m_Days.Length; i++)
            {
                yield return m_Days[i];
            }
        }
    }

    class TestDaysOfTheWeek
    {
        static void Main()
        {
            // Create an instance of the collection class
            DaysOfTheWeek week = new DaysOfTheWeek();

            // Iterate with foreach
            foreach (string day in week)
            {
                Console.Write(day + " ");
            }
            Console.Read();
        }
    }
}
