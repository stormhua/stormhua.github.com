﻿using System;
using System.Collections.Generic;
using System.Text;
using TeachManageSystem.Model;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace TeachManageSystem.DAL
{
    public class Authorities
    {
        private const string SQL_SELECT_AUTHORITIES_TERM = "SELECT ID,[Function],Operate,Description FROM Authorities WHERE ";
        private const string SQL_SELECT_AUTHORITIES = "SELECT ID,[Function],Operate,Description FROM Authorities";

        /// <summary>
        /// 通过条件查询出某有字段
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public AuthoritiesInfo GetAuthoritiesData(string WhereSentence)
        {
            AuthoritiesInfo info = null;
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_AUTHORITIES_TERM + WhereSentence, null);
            if (rdr.Read())
            {
                info = new AuthoritiesInfo(rdr["ID"], rdr["Function"], rdr["Operate"], rdr["Description"]);
            }
            else
            {
                info = new AuthoritiesInfo();
            }
            return info;
        }
        /// <summary>
        /// 读取所有的数据
        /// </summary>
        /// <returns></returns>
        public IList<AuthoritiesInfo> GetAuthoritiesAllData()
        {
            IList<AuthoritiesInfo> info = new List<AuthoritiesInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_AUTHORITIES, null);
            while (rdr.Read())
            {
                AuthoritiesInfo ninfo = new AuthoritiesInfo(rdr["ID"], rdr["Function"], rdr["Operate"], rdr["Description"]);
                info.Add(ninfo);
            }
            return info;
        }
        /// <summary>
        /// 通过条件读取某一行数据
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public IList<AuthoritiesInfo> GetAuthoritiesDataID(string WhereSentence)
        {
            IList<AuthoritiesInfo> info = new List<AuthoritiesInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_AUTHORITIES_TERM + WhereSentence, null);
            while (rdr.Read())
            {
                AuthoritiesInfo ninfo = new AuthoritiesInfo(rdr["ID"], rdr["Function"], rdr["Operate"], rdr["Description"]);
                info.Add(ninfo);
            }
            return info;
        }
    }
}
