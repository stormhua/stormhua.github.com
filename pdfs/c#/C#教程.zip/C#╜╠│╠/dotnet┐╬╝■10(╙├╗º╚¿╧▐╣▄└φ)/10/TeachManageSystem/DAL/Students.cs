﻿using System;
using System.Collections.Generic;
using System.Text;
using TeachManageSystem.Model;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
namespace TeachManageSystem.DAL
{
    public class Students
    {
        private const string SQL_SELECT_STUDENTS_TERM = "SELECT ID,Number,Name,Sex,Department,Grade FROM Students WHERE ";
        private const string SQL_INSERT_STUDENTS = "Students_Create";
        private const string SQL_DELETE_STUDENTS = "Students_DeleteByID";
        private const string SQL_UPDATE_STUDENTS = "Students_Update";
        private const string SQL_SELECT_STUDENTS = "SELECT ID,Number,Name,Sex,Department,Grade FROM Students";
        private const string PARM_STUDENTSID = "@id";
        private const string PARM_STUDENTSNUMBER = "@number";
        private const string PARM_STUDENTSNAME = "@name";
        private const string PARM_STUDENTSSEX = "@sex";
        private const string PARM_STUDENTSDEPARTMENT = "@department";
        private const string PARM_STUDENTSGRADE = "@grade";
        private const string PARM_RETURNVALUE = "ReturnValue";
        /// <summary>
        /// 通过条件查询出某有字段
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public StudentsInfo GetStudentsData(string WhereSentence)
        {
            StudentsInfo info = null;
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_STUDENTS_TERM + WhereSentence, null);
            if (rdr.Read())
            {
                info = new StudentsInfo(rdr["ID"], rdr["Number"], rdr["Name"], rdr["Sex"], rdr["Department"], rdr["Grade"]);
            }
            else
            {
                info = new StudentsInfo();
            }
            return info;
        }
        /// <summary>
        /// 读取所有的数据
        /// </summary>
        /// <returns></returns>
        public IList<StudentsInfo> GetStudentsAllData()
        {
            IList<StudentsInfo> info = new List<StudentsInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_STUDENTS, null);
            while (rdr.Read())
            {
                StudentsInfo ninfo = new StudentsInfo(rdr["ID"], rdr["Number"], rdr["Name"], rdr["Sex"], rdr["Department"], rdr["Grade"]);
                info.Add(ninfo);
            }
            return info;
        }
        /// <summary>
        /// 通过条件读取某一行数据
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public IList<StudentsInfo> GetStudentsDataID(string WhereSentence)
        {
            IList<StudentsInfo> info = new List<StudentsInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_STUDENTS_TERM + WhereSentence, null);
            while (rdr.Read())
            {
                StudentsInfo ninfo = new StudentsInfo(rdr["ID"], rdr["Number"], rdr["Name"], rdr["Sex"], rdr["Department"], rdr["Grade"]);
                info.Add(ninfo);
            }
            return info;
        }
        /// <summary>
        /// 插入操作
        /// </summary>
        /// <param name="info">表的实体</param>
        public int InsertStudents(StudentsInfo info)
        {
            SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_STUDENTSNUMBER, SqlDbType.VarChar, 10),
                new SqlParameter(PARM_STUDENTSNAME, SqlDbType.VarChar, 10),
                new SqlParameter(PARM_STUDENTSSEX, SqlDbType.VarChar, 2),
                new SqlParameter(PARM_STUDENTSDEPARTMENT, SqlDbType.VarChar, 50),
                new SqlParameter(PARM_STUDENTSGRADE, SqlDbType.VarChar, 15),
                new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
                };
            parm[0].Value = info.Number;
            parm[1].Value = info.Name;
            parm[2].Value = info.Sex;
            parm[3].Value = info.Department;
            parm[4].Value = info.Grade;
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_INSERT_STUDENTS, parm);
            return i;
        }
        /// <summary>
        /// 根据ID删除数据
        /// </summary>
        /// <param name="id">输入的ID值</param>
        public int DeleteStudents(int id)
        {
            SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_STUDENTSID, SqlDbType.Int, 10),
                new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
                };
            parm[0].Value = id;
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_DELETE_STUDENTS, parm);
            return i;
        }
        /// <summary>
        /// 修改操作
        /// </summary>
        /// <param name="info"></param>
        public int UpdateStudents(StudentsInfo info)
        {
            SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_STUDENTSID, SqlDbType.Int),
                new SqlParameter(PARM_STUDENTSNUMBER, SqlDbType.VarChar, 10),
                new SqlParameter(PARM_STUDENTSNAME, SqlDbType.VarChar, 10),
                new SqlParameter(PARM_STUDENTSSEX, SqlDbType.VarChar, 2),
                new SqlParameter(PARM_STUDENTSDEPARTMENT, SqlDbType.VarChar, 50),
                new SqlParameter(PARM_STUDENTSGRADE, SqlDbType.VarChar, 15),
                new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
                };
            parm[0].Value = info.ID;
            parm[1].Value = info.Number;
            parm[2].Value = info.Name;
            parm[3].Value = info.Sex;
            parm[4].Value = info.Department;
            parm[5].Value = info.Grade;
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_UPDATE_STUDENTS, parm);
            return i;
        }
    }
}
