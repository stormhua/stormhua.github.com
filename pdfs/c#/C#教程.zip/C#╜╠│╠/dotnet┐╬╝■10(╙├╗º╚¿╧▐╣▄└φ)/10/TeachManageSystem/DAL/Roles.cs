﻿using System;
using System.Collections.Generic;
using System.Text;
using TeachManageSystem.Model;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
namespace TeachManageSystem.DAL
{
    public class Roles
    {
        private const string SQL_SELECT_ROLES_TERM = "SELECT ID,RoleName,Authority FROM Roles WHERE ";
        //private const string SQL_INSERT_ROLES = "Roles_Create";
        //private const string SQL_DELETE_ROLES = "Roles_DeleteByID";
        private const string SQL_UPDATE_ROLES = "Roles_Update";
        private const string SQL_SELECT_ROLES = "SELECT ID,RoleName,Authority FROM Roles";
        private const string PARM_ROLESID = "@id";
        private const string PARM_ROLESROLENAME = "@rolename";
        private const string PARM_ROLESAUTHORITY = "@authority";
        private const string PARM_RETURNVALUE = "ReturnValue";
        /// <summary>
        /// 通过条件查询出某条记录
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public RolesInfo GetRolesData(string WhereSentence)
        {
            RolesInfo info = null;
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_ROLES_TERM + WhereSentence, null);
            if (rdr.Read())
            {
                info = new RolesInfo(rdr["ID"], rdr["RoleName"], rdr["Authority"]);
            }
            else
            {
                info = new RolesInfo();
            }
            return info;
        }
        /// <summary>
        /// 读取所有的数据
        /// </summary>
        /// <returns></returns>
        public IList<RolesInfo> GetRolesAllData()
        {
            IList<RolesInfo> info = new List<RolesInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_ROLES, null);
            while (rdr.Read())
            {
                RolesInfo ninfo = new RolesInfo(rdr["ID"], rdr["RoleName"], rdr["Authority"]);
                info.Add(ninfo);
            }
            return info;
        }
        /// <summary>
        /// 通过条件读取某一行数据
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public IList<RolesInfo> GetRolesDataID(string WhereSentence)
        {
            IList<RolesInfo> info = new List<RolesInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_ROLES_TERM + WhereSentence, null);
            while (rdr.Read())
            {
                RolesInfo ninfo = new RolesInfo(rdr["ID"], rdr["RoleName"], rdr["Authority"]);
                info.Add(ninfo);
            }
            return info;
        }
        ///// <summary>
        ///// 插入操作
        ///// </summary>
        ///// <param name="info">表的实体</param>
        //public int InsertRoles(RolesInfo info)
        //{
        //    SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_ROLESROLENAME, SqlDbType.NVarChar, 10),
        //        new SqlParameter(PARM_ROLESAUTHORITY, SqlDbType.NVarChar, 50),
        //        new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
        //        };
        //    parm[0].Value = info.RoleName;
        //    parm[1].Value = info.Authority;
        //    int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_INSERT_ROLES, parm);
        //    return i;
        //}
        ///// <summary>
        ///// 根据ID删除数据
        ///// </summary>
        ///// <param name="id">输入的ID值</param>
        //public int DeleteRoles(int id)
        //{
        //    SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_ROLESID, SqlDbType.Int, 10),
        //        new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
        //        };
        //    parm[0].Value = id;
        //    int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_DELETE_ROLES, parm);
        //    return i;
        //}
        /// <summary>
        /// 修改操作
        /// </summary>
        /// <param name="info"></param>
        public int UpdateRoles(RolesInfo info)
        {
            SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_ROLESID, SqlDbType.Int),
                new SqlParameter(PARM_ROLESROLENAME, SqlDbType.NVarChar, 10),
                new SqlParameter(PARM_ROLESAUTHORITY, SqlDbType.NVarChar, 50),
                new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
                };
            parm[0].Value = info.ID;
            parm[1].Value = info.RoleName;
            parm[2].Value = info.Authority;
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_UPDATE_ROLES, parm);
            return i;
        }
    }
}
