using System;
using System.Collections.Generic;
using System.Text;
using TeachManageSystem.Model;

namespace TeachManageSystem.DAL
{
    class PersonFactory
    {
        public static PersonInfo CreatePerson(int userID,RolesInfo role)
        {
            if (role.RoleName == "ѧ��")
            {
                return (new Students()).GetStudentsData(string.Format("ID={0}", userID));
            }
            else
            {
                return (new Teachers()).GetTeachersData(string.Format("ID={0}", userID));
            }
        }
    }
}
