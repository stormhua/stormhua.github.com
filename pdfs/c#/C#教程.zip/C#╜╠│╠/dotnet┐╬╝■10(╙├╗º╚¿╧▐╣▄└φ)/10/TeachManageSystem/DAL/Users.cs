﻿using System;
using System.Collections.Generic;
using System.Text;
using TeachManageSystem.Model;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
namespace TeachManageSystem.DAL
{
    public class Users
    {
        private const string SQL_SELECT_USERS_TERM = "SELECT ID,UserID,Password,RoleID,Authority FROM Users WHERE ";
        private const string SQL_INSERT_USERS = "Users_Create";
        private const string SQL_DELETE_USERS = "Users_DeleteByID";
        private const string SQL_UPDATE_USERS = "Users_Update";
        private const string SQL_SELECT_USERS = "SELECT ID,UserID,Password,RoleID,Authority FROM Users";
        private const string PARM_USERSID = "@id";
        private const string PARM_USERSUSERID = "@userid";
        private const string PARM_USERSPASSWORD = "@password";
        private const string PARM_USERSROLEID = "@roleid";
        private const string PARM_USERSAUTHORITY = "@authority";
        private const string PARM_RETURNVALUE = "ReturnValue";
        /// <summary>
        /// 通过条件查询出某有字段
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public UsersInfo GetUsersData(string WhereSentence)
        {
            UsersInfo info = null;
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_USERS_TERM + WhereSentence, null);
            if (rdr.Read())
            {
                RolesInfo infoRole = (new Roles()).GetRolesData(string.Format("ID={0}", rdr["RoleID"]));
                PersonInfo infoPerson = PersonFactory.CreatePerson((int)rdr["UserID"], infoRole);
                info = new UsersInfo(rdr["ID"], infoPerson, rdr["Password"], infoRole, rdr["Authority"]);
            }
            else
            {
                info = new UsersInfo();
            }
            return info;
        }
        /// <summary>
        /// 读取所有的数据
        /// </summary>
        /// <returns></returns>
        public IList<UsersInfo> GetUsersAllData()
        {
            IList<UsersInfo> info = new List<UsersInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_USERS, null);
            while (rdr.Read())
            {
                RolesInfo infoRole = (new Roles()).GetRolesData(string.Format("ID={0}", rdr["RoleID"]));
                PersonInfo infoPerson = PersonFactory.CreatePerson((int)rdr["UserID"], infoRole);
                UsersInfo ninfo = new UsersInfo(rdr["ID"], infoPerson, rdr["Password"], infoRole, rdr["Authority"]);
                info.Add(ninfo);
            }
            return info;
        }
        /// <summary>
        /// 通过条件读取某一行数据
        /// </summary>
        /// <param WhereSentence="WhereSentence">过滤语句</param>
        /// <returns></returns>
        public IList<UsersInfo> GetUsersDataID(string WhereSentence)
        {
            IList<UsersInfo> info = new List<UsersInfo>();
            SqlDataReader rdr = SqlHelper.ExecuteReader(SqlHelper.ConnectionString, CommandType.Text, SQL_SELECT_USERS_TERM + WhereSentence, null);
            while (rdr.Read())
            {
                RolesInfo infoRole = (new Roles()).GetRolesData(string.Format("ID={0}", rdr["RoleID"]));
                PersonInfo infoPerson = PersonFactory.CreatePerson((int)rdr["UserID"], infoRole);
                UsersInfo ninfo = new UsersInfo(rdr["ID"], infoPerson, rdr["Password"], infoRole, rdr["Authority"]);
                info.Add(ninfo);
            }
            return info;
        }
        /// <summary>
        /// 插入操作
        /// </summary>
        /// <param name="info">表的实体</param>
        public int InsertUsers(UsersInfo info)
        {
            SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_USERSUSERID, SqlDbType.Char, 10),
                new SqlParameter(PARM_USERSPASSWORD, SqlDbType.Binary, 24),
                new SqlParameter(PARM_USERSROLEID, SqlDbType.Int),
                new SqlParameter(PARM_USERSAUTHORITY, SqlDbType.NVarChar, 50),
                new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
                };
            parm[0].Value = info.Person.ID;
            parm[1].Value = info.Password;
            parm[2].Value = info.Role.ID;
            parm[3].Value = info.Authority;
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_INSERT_USERS, parm);
            return i;
        }
        /// <summary>
        /// 根据ID删除数据
        /// </summary>
        /// <param name="id">输入的ID值</param>
        public int DeleteUsers(int ID)
        {
            SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_USERSID, SqlDbType.Int),
                new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
                };
            parm[0].Value = ID;
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_DELETE_USERS, parm);
            return i;
        }
        /// <summary>
        /// 修改操作
        /// </summary>
        /// <param name="info"></param>
        public int UpdateUsers(UsersInfo info)
        {
            SqlParameter[] parm = new SqlParameter[]{new SqlParameter(PARM_USERSID, SqlDbType.Int),
                new SqlParameter(PARM_USERSUSERID, SqlDbType.Char, 10),
                new SqlParameter(PARM_USERSPASSWORD, SqlDbType.Binary, 24),
                new SqlParameter(PARM_USERSROLEID, SqlDbType.Int),
                new SqlParameter(PARM_USERSAUTHORITY, SqlDbType.NVarChar, 50),
                new SqlParameter(PARM_RETURNVALUE,SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null)
                };
            parm[0].Value = info.ID;
            parm[1].Value = info.Person.ID;
            parm[2].Value = info.Password;
            parm[3].Value = info.Role.ID;
            parm[4].Value = info.Authority;
            int i = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString, CommandType.StoredProcedure, SQL_UPDATE_USERS, parm);
            return i;
        }
    }
}
