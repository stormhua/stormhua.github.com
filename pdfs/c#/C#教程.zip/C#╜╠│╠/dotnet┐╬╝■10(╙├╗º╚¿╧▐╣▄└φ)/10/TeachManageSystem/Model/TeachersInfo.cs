﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TeachManageSystem.Model
{
    [Serializable]
    public class TeachersInfo:PersonInfo
    {

        string jobtitle;//职称字段
        string headship;//职务字段
        /// <summary>
        /// 构造函数
        /// </summary>
        public TeachersInfo() { }
        /// <summary>
        /// 带所有参数的构造函数
        /// </summary>
        public TeachersInfo(object id, object number, object name, object sex, object jobtitle, object headship)
        {
            if (id.ToString() == "")
            {
                this.id = 0;
            }
            else
            {
                this.id = int.Parse(id.ToString());//ID字段赋值
            }
            this.number = number.ToString();//工号字段赋值
            this.name = name.ToString();//姓名字段赋值
            this.sex = sex.ToString();//性别字段赋值
            this.jobtitle = jobtitle.ToString();//职称字段赋值
            this.headship = headship.ToString();//职务字段赋值
        }
        /// <summary>
        /// 插入操作的构造函数
        /// </summary>
        public TeachersInfo(object number, object name, object sex, object jobtitle, object headship)
        {
            this.number = number.ToString();//工号字段赋值
            this.name = name.ToString();//姓名字段赋值
            this.sex = sex.ToString();//性别字段赋值
            this.jobtitle = jobtitle.ToString();//职称字段赋值
            this.headship = headship.ToString();//职务字段赋值
        }

        /// <summary>
        /// 职称属性
        /// </summary>
        public string JobTitle
        {
            get { return jobtitle; }
            set { jobtitle = value; }
        }
        /// <summary>
        /// 职务属性
        /// </summary>
        public string Headship
        {
            get { return headship; }
            set { headship = value; }
        }
    }
}
