﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TeachManageSystem.Model
{
    [Serializable]
    public class AuthoritiesInfo
    {
        int id;//编号字段
        string function;//功能字段
        string operate;//操作字段
        string description;//权限描述字段
        string authority;//权限允许（禁止；0可选；1已选）
        bool ispermit;//是否允许
        
        /// <summary>
        /// 构造函数
        /// </summary>
        public AuthoritiesInfo() { }
        /// <summary>
        /// 带所有参数的构造函数
        /// </summary>
        public AuthoritiesInfo(object id, object function, object operate, object description)
        {
            if (id.ToString() == "")
            {
                this.id = 0;
            }
            else
            {
                this.id = int.Parse(id.ToString());//ID字段赋值
            }
            this.function = function.ToString();//功能字段赋值
            this.operate = operate.ToString();//操作字段赋值
            this.description = description.ToString();//权限描述字段赋值
        }
        /// <summary>
        /// 插入操作的构造函数
        /// </summary>
        public AuthoritiesInfo(object function, object operate, object description)
        {
            this.function = function.ToString();//功能字段赋值
            this.operate = operate.ToString();//操作字段赋值
            this.description = description.ToString();//权限描述字段赋值
        }
        /// <summary>
        /// 编号属性
        /// </summary>
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        /// <summary>
        /// 功能属性
        /// </summary>
        public string Function
        {
            get { return function; }
            set { function = value; }
        }
        /// <summary>
        /// 操作属性
        /// </summary>
        public string Operate
        {
            get { return operate; }
            set { operate = value; }
        }
        /// <summary>
        /// 权限描述属性
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        /// <summary>
        /// 权限（允许；可选；禁止）
        /// </summary>
        public string Authority
        {
            get { return authority; }
            set { authority = value; }
        }

        /// <summary>
        /// 允许（true）；禁止（false）；
        /// </summary>
        public bool IsPermit
        {
            get { return ispermit; }
            set { ispermit = value; }
        }
    }
}
