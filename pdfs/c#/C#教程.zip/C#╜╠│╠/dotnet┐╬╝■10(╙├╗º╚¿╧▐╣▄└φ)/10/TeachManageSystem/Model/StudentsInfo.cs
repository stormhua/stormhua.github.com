﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TeachManageSystem.Model
{
    [Serializable]
    public class StudentsInfo:PersonInfo
    {
        //int id;//主键字段
        //string number;//学号字段
        //string name;//姓名字段
        //string sex;//性别字段
        string department;//院系字段
        string grade;//年级字段
        /// <summary>
        /// 构造函数
        /// </summary>
        public StudentsInfo() { }
        /// <summary>
        /// 带所有参数的构造函数
        /// </summary>
        public StudentsInfo(object id, object number, object name, object sex, object department, object grade)
        {
            if (id.ToString() == "")
            {
                this.id = 0;
            }
            else
            {
                this.id = int.Parse(id.ToString());//ID字段赋值
            }
            this.number = number.ToString();//学号字段赋值
            this.name = name.ToString();//姓名字段赋值
            this.sex = sex.ToString();//性别字段赋值
            this.department = department.ToString();//院系字段赋值
            this.grade = grade.ToString();//年级字段赋值
        }
        /// <summary>
        /// 插入操作的构造函数
        /// </summary>
        public StudentsInfo(object number, object name, object sex, object department, object grade)
        {
            this.number = number.ToString();//学号字段赋值
            this.name = name.ToString();//姓名字段赋值
            this.sex = sex.ToString();//性别字段赋值
            this.department = department.ToString();//院系字段赋值
            this.grade = grade.ToString();//年级字段赋值
        }
        ///// <summary>
        ///// 主键属性
        ///// </summary>
        //public int ID
        //{
        //    get { return id; }
        //    set { id = value; }
        //}
        ///// <summary>
        ///// 学号属性
        ///// </summary>
        //public string Number
        //{
        //    get { return number; }
        //    set { number = value; }
        //}
        ///// <summary>
        ///// 姓名属性
        ///// </summary>
        //public string Name
        //{
        //    get { return name; }
        //    set { name = value; }
        //}
        ///// <summary>
        ///// 性别属性
        ///// </summary>
        //public string Sex
        //{
        //    get { return sex; }
        //    set { sex = value; }
        //}
        /// <summary>
        /// 院系属性
        /// </summary>
        public string Department
        {
            get { return department; }
            set { department = value; }
        }
        /// <summary>
        /// 年级属性
        /// </summary>
        public string Grade
        {
            get { return grade; }
            set { grade = value; }
        }
    }
}
