﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TeachManageSystem.Model
{
    [Serializable]
    public class RolesInfo
    {
        int id;//主键字段
        string rolename;//角色名称字段
        string authority;//权限字段
        /// <summary>
        /// 构造函数
        /// </summary>
        public RolesInfo() { }
        /// <summary>
        /// 带所有参数的构造函数
        /// </summary>
        public RolesInfo(object id, object rolename, object authority)
        {
            if (id.ToString() == "")
            {
                this.id = 0;
            }
            else
            {
                this.id = int.Parse(id.ToString());//ID字段赋值
            }
            this.rolename = rolename.ToString();//角色名称字段赋值
            this.authority = authority.ToString();//权限字段赋值
        }
        /// <summary>
        /// 插入操作的构造函数
        /// </summary>
        public RolesInfo(object rolename, object authority)
        {
            this.rolename = rolename.ToString();//角色名称字段赋值
            this.authority = authority.ToString();//权限字段赋值
        }
        /// <summary>
        /// 主键属性
        /// </summary>
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        /// <summary>
        /// 角色名称属性
        /// </summary>
        public string RoleName
        {
            get { return rolename; }
            set { rolename = value; }
        }
        /// <summary>
        /// 权限属性
        /// </summary>
        public string Authority
        {
            get { return authority; }
            set { authority = value; }
        }
    }
}
