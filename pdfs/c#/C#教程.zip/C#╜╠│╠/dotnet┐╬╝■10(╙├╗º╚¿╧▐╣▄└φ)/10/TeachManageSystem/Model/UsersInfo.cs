﻿using System;
using System.Collections.Generic;
using System.Text;
namespace TeachManageSystem.Model
{
    [Serializable]
    public class UsersInfo
    {
        int id;//ID字段
        //int userid;//教师或学生ID字段
        PersonInfo person;
        byte[] password;//Password字段
        //int roleid;//RoleID字段
        RolesInfo role;
        string authority;//用户权限字段
        IList<AuthoritiesInfo> authorities;

        /// <summary>
        /// 构造函数
        /// </summary>
        public UsersInfo() { }
        /// <summary>
        /// 带所有参数的构造函数
        /// </summary>
        public UsersInfo(object id, object person, object password, object role, object authority)
        {
            if (id.ToString() == "")
            {
                this.id = 0;
            }
            else
            {
                this.id = int.Parse(id.ToString());//ID字段赋值
            }
            this.person = (PersonInfo)person;//用户基本资料
            if (password.ToString() == "")
            {
                this.password = null;
            }
            else
            {
                this.password = (byte[])password;//Password字段赋值
            }
            this.role = (RolesInfo)role;//角色
            this.authority = authority.ToString();//用户权限字段赋值
        }
        /// <summary>
        /// 插入操作的构造函数
        /// </summary>
        public UsersInfo(object person, object password, object role, object authority)
        {
            this.person = (PersonInfo)person;//用户基本资料
            if (password.ToString() == "")
            {
                this.password = null;
            }
            else
            {
                this.password = (byte[])password;//Password字段赋值
            }
            this.role = (RolesInfo)role;//角色
            this.authority = authority.ToString();//用户权限字段赋值
        }
        /// <summary>
        /// 属性
        /// </summary>
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        /// <summary>
        /// 教师或学生ID属性
        /// </summary>
        public PersonInfo Person
        {
            get { return person; }
            set { person = value; }
        }
        /// <summary>
        /// 属性
        /// </summary>
        public byte[] Password
        {
            get { return password; }
            set { password = value; }
        }
        /// <summary>
        /// 属性
        /// </summary>
        public RolesInfo Role
        {
            get { return role; }
            set { role = value; }
        }
        /// <summary>
        /// 用户权限属性
        /// </summary>
        public string Authority
        {
            get 
            {
                //如果权限字符串为空，则返回角色的默认权限
                if (string.IsNullOrEmpty(authority))
                    return Role.Authority;
                else
                    return authority; 
            }
            set { authority = value; }
        }

        /// <summary>
        /// 用户权限集合
        /// </summary>
        public IList<AuthoritiesInfo> Authorities
        {
            get { return authorities; }
            set { authorities = value; }
        }
    }
}
