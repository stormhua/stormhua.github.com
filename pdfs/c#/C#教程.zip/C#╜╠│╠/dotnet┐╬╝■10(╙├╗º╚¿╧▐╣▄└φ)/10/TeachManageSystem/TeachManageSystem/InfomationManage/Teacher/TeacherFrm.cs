using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachManageSystem.BLL;
using TeachManageSystem.Model;

namespace TeachManageSystem
{
    public partial class TeacherFrm : Form
    {
        /// <summary>
        /// ��Ų�ѯ�õ��ļ�¼��
        /// </summary>
        private IList<TeachersInfo> _teachersInfo = null;

        /// <summary>
        /// ���SQL���
        /// </summary>
        private string _sqlWhere = "id > 0";

        /// <summary>
        /// Ĭ�ϵĹ��캯��
        /// </summary>
        public TeacherFrm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// ��������ʱִ�еĳ�ʼ������
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TeacherFrm_Load(object sender, EventArgs e)
        {
            //Ȩ������
            SetAuthority();

            //һЩ�ؼ��ĳ�ʼ��
            AdjustColumnOrder();//DataGridView�ؼ����ֶ�����˳��
            cbQueryField.SelectedIndex = 0;//���ò�ѯ����Ĭ��ֵ
            tvJobTitle.ExpandAll();//չ�����ؼ�

            //��ʾ���н�ʦ������
            Query();
        }

        /// <summary>
        /// Ȩ������
        /// </summary>
        private void SetAuthority()
        {
            tsbQuery.Enabled = LoginFrm.CurrentUser.Authorities[0].IsPermit;
            tsbAdd.Enabled = LoginFrm.CurrentUser.Authorities[1].IsPermit;
            tsbUpdate.Enabled = LoginFrm.CurrentUser.Authorities[1].IsPermit;
            tsbDelete.Enabled = LoginFrm.CurrentUser.Authorities[1].IsPermit;
        }

        /// <summary>
        /// DataGridView�ؼ����ֶ�����˳��
        /// </summary>
        private void AdjustColumnOrder()
        {
            dgvTeacher.Columns["ColumnID"].Visible = false;
            dgvTeacher.Columns["ColumnNumber"].DisplayIndex = 0;
            dgvTeacher.Columns["ColumnName"].DisplayIndex = 1;
            dgvTeacher.Columns["ColumnSex"].DisplayIndex = 2;
            dgvTeacher.Columns["ColumnJobTitle"].DisplayIndex = 3;
            dgvTeacher.Columns["ColumnHeadship"].DisplayIndex = 4;
        }

        /// <summary>
        /// ִ�в�ѯ
        /// </summary>
        private void tsbQuery_Click(object sender, EventArgs e)
        {
            CreateSQL(cbQueryField.Text, tbQueryKey.Text, rbExact.Checked);
            Query();
        }

        /// <summary>
        /// ���ɲ�ѯ����
        /// </summary>
        /// <param name="field">��ѯ�ֶ�</param>
        /// <param name="value">��ѯ�ؼ���</param>
        /// <param name="isExact">�Ǿ�ȷ��ѯ��</param>
        private void CreateSQL(string field,string value,bool isExact)
        {
            switch (field)
            {
                case "����":
                    _sqlWhere = string.Format(isExact ? "Number = '{0}'" : "Number like '%{0}%'", value);
                    break;
                case "����":
                    _sqlWhere = string.Format(isExact ? "Name = '{0}'" : "Name like '%{0}%'", value);
                    break;
                case "�Ա�":
                    _sqlWhere = string.Format(isExact ? "Sex = '{0}'" : "Sex like '%{0}%'", value);
                    break;
                case "ְ��":
                    _sqlWhere = string.Format(isExact ? "JobTitle = '{0}'" : "JobTitle like '%{0}%'", value);
                    break;
                case "ְ��":
                    _sqlWhere = string.Format(isExact ? "Headship = '{0}'" : "Headship like '%{0}%'", value);
                    break;
                default:
                    _sqlWhere = "id > 0"; //�������ѯ�������Բ鴦ȫ����¼��id��Զ����0��
                    break;
            }
        }

        /// <summary>
        /// ��ʾ��ѯ�Ľṹ��������
        /// </summary>
        private void Display()
        {
            ssCount.Items["tsslCount"].Text = _teachersInfo.Count.ToString();//���鵽�ļ�¼������
            dgvTeacher.DataSource = _teachersInfo;//����ѯ�Ľṹ��ʾ��DataGridView�ؼ�
        }

        /// <summary>
        /// ��װ�Ĳ�ѯ����
        /// </summary>
        private void Query()
        {
            _teachersInfo = (new TeachersBll()).GetTeachersDataID(_sqlWhere);
            Display();
        }

        /// <summary>
        /// ѡ�����ؼ��Ľڵ�������¼�
        /// </summary>
        private void tvJobTitle_AfterSelect(object sender, TreeViewEventArgs e)
        {
            CreateSQL("ְ��", tvJobTitle.SelectedNode.Text, true);
            Query();
        }

        /// <summary>
        /// ����
        /// </summary>
        private void tsbAdd_Click(object sender, EventArgs e)
        {
            TeacherInfoFrm form = new TeacherInfoFrm();
            form.ShowDialog();
            Query();
        }

        /// <summary>
        /// �޸�
        /// </summary>
        private void tsbUpdate_Click(object sender, EventArgs e)
        {
            TeacherInfoFrm form = new TeacherInfoFrm((TeachersInfo)dgvTeacher.SelectedRows[0].DataBoundItem);
            form.ShowDialog();
            //Query();
        }

        /// <summary>
        /// ɾ��
        /// </summary>
        private void tsbDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("ȷ��ɾ����", "��ʾ", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                string message = "";
                (new TeachersBll()).DeleteTeachers(((TeachersInfo)dgvTeacher.SelectedRows[0].DataBoundItem).ID, out message);
                MessageBox.Show(message);
                Query();
            }            
        }

        /// <summary>
        /// ˢ��
        /// </summary>
        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            Query();
        }

        /// <summary>
        /// �˳���ʦ���Ϲ�������
        /// </summary>
        private void tsbExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}