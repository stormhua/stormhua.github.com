using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachManageSystem.Model;
using TeachManageSystem.BLL;
using System.Security.Cryptography;

namespace TeachManageSystem
{
    public partial class RoleSelectFrm : Form
    {
        private UsersInfo _user;
        private string _role;
        private UsersBll _userBll = new UsersBll();

        public RoleSelectFrm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// �����ʦ�û��Ĺ��캯��
        /// </summary>
        /// <param name="teacher"></param>
        public RoleSelectFrm(TeachersInfo teacher)
        {
            InitializeComponent();

            _user = new UsersInfo(teacher, _userBll.CreateDbPassword("888888"), null, "");
            _role = "ID<3";
        }

        /// <summary>
        /// ����ѧ���û��Ĺ��캯��
        /// </summary>
        /// <param name="teacher"></param>
        public RoleSelectFrm(StudentsInfo student)
        {
            InitializeComponent();

            _user = new UsersInfo(student, _userBll.CreateDbPassword("888888"), null, "");
            _role = "ID=3";
        }

        /// <summary>
        /// �޸��û���ɫ�Ĺ��캯��
        /// </summary>
        /// <param name="user"></param>
        public RoleSelectFrm(UsersInfo user)
        {
            InitializeComponent();
            _user = user;
            _role = "ID<3";
        }

        private void RoleSelectFrm_Load(object sender, EventArgs e)
        {
            cbbRole.DisplayMember = "RoleName";
            cbbRole.DataSource = (new RolesBll()).GetRolesDataID(_role);            
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            _user.Role = (RolesInfo)cbbRole.SelectedItem;
            string message = "";
            if (_user.ID > 0)
            {
                (new UsersBll()).UpdateUsers(_user, out message);
            }
            else
            {
                int returnValue = (new UsersBll()).InsertUsers(_user, out message);
                if (returnValue > 0)
                    _user.Person.IsActived = "��";
            }
            this.Close();
            MessageBox.Show(message);
        }


    }
}