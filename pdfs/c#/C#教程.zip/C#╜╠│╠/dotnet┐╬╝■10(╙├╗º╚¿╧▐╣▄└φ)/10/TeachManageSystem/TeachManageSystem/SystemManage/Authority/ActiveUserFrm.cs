using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachManageSystem.BLL;
using TeachManageSystem.Model;

namespace TeachManageSystem
{
    public partial class ActiveUserFrm : Form
    {
        // BLL�����
        private TeachersBll _teachersBll = new TeachersBll();
        private StudentsBll _studentsBll = new StudentsBll();

        public ActiveUserFrm()
        {
            InitializeComponent();
        }

        //�����ʼ������
        private void ActiveUserFrm_Load(object sender, EventArgs e)
        {
            AdjustColumnOrder();
            ButtonState();
        }

        /// <summary>
        /// DataGridView�ؼ����ֶ�����˳��
        /// </summary>
        private void AdjustColumnOrder()
        {
            //��ʦ������ʾ
            dgvTeacher.Columns["ColumnID"].Visible = false;
            dgvTeacher.Columns["ColumnIsActived"].DisplayIndex = 0;
            dgvTeacher.Columns["ColumnNumber"].DisplayIndex = 1;
            dgvTeacher.Columns["ColumnName"].DisplayIndex = 2;
            dgvTeacher.Columns["ColumnSex"].DisplayIndex = 3;
            dgvTeacher.Columns["ColumnJobTitle"].DisplayIndex = 4;
            dgvTeacher.Columns["ColumnHeadship"].DisplayIndex = 5;    

            dgvTeacher.DataSource = _teachersBll.GetAllTeachersAndStatus();

            //ѧ��������ʾ
            dgvStudent.Columns["ColumnStudentID"].Visible = false;
            dgvStudent.Columns["ColumnStudentIsActived"].DisplayIndex = 0;
            dgvStudent.Columns["ColumnStudentNumber"].DisplayIndex = 1;
            dgvStudent.Columns["ColumnStudentName"].DisplayIndex = 2;
            dgvStudent.Columns["ColumnStudentSex"].DisplayIndex = 3;
            dgvStudent.Columns["ColumnStudentDepartment"].DisplayIndex = 4;
            dgvStudent.Columns["ColumnStudentGrade"].DisplayIndex = 5;

            dgvStudent.DataSource = _studentsBll.GetAllStudentsAndStatus();
        }

        /// <summary>
        /// ѡ��һ�����ϼ�¼���л����ť��״̬
        /// </summary>
        private void dgvTeacher_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ButtonState();
        }

        /// <summary>
        /// �л����ť��״̬
        /// </summary>
        private void ButtonState()
        {
            if( tabControl1.SelectedIndex == 0 )//��ǩҳΪ����ʦ��
                btActive.Enabled = (dgvTeacher.SelectedRows[0].Cells["ColumnIsActived"].Value.ToString() == "");
            else //��ǩҳΪ��ѧ����
                btActive.Enabled = (dgvStudent.SelectedRows[0].Cells["ColumnStudentIsActived"].Value.ToString() == "");
        }

        /// <summary>
        /// ���ť�ĵ����¼�
        /// </summary>
        private void btActive_Click(object sender, EventArgs e)
        {
            RoleSelectFrm form;
            if (tabControl1.SelectedIndex == 0) //��ǩҳΪ����ʦ��
            {
                //��ʾѡ���ɫ�Ĵ���
                form = new RoleSelectFrm(dgvTeacher.SelectedRows[0].DataBoundItem as TeachersInfo);
                dgvTeacher.Refresh();//ˢ�½�ʦ����
            }
            else //��ǩҳΪ��ѧ����
            {
                //��ʾѡ���ɫ�Ĵ���
                form = new RoleSelectFrm(dgvStudent.SelectedRows[0].DataBoundItem as StudentsInfo);
                dgvStudent.Refresh();//ˢ��ѧ������
            }
            form.ShowDialog();
        }

        /// <summary>
        /// �رյ�ǰ����
        /// </summary>
        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}