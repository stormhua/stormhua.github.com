﻿namespace TeachManageSystem
{
    partial class UsersFrm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UsersFrm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.btModifyPwd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btActiveUser = new System.Windows.Forms.ToolStripButton();
            this.btDeleteUser = new System.Windows.Forms.ToolStripButton();
            this.btModifyAuth = new System.Windows.Forms.ToolStripButton();
            this.btModifyRole = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btExit = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tvUsers = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dgvAuthority = new System.Windows.Forms.DataGridView();
            this.ColumnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnAuthority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnFunction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnOperate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnIsPermit = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.lblAuthTitle = new System.Windows.Forms.Label();
            this.toolStrip2.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuthority)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(650, 34);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("隶书", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(-4, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(654, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "用户权限管理";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btModifyPwd,
            this.toolStripSeparator1,
            this.btActiveUser,
            this.btDeleteUser,
            this.btModifyAuth,
            this.btModifyRole,
            this.toolStripSeparator2,
            this.btExit});
            this.toolStrip2.Location = new System.Drawing.Point(0, 34);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip2.Size = new System.Drawing.Size(650, 25);
            this.toolStrip2.TabIndex = 2;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // btModifyPwd
            // 
            this.btModifyPwd.Image = ((System.Drawing.Image)(resources.GetObject("btModifyPwd.Image")));
            this.btModifyPwd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btModifyPwd.Name = "btModifyPwd";
            this.btModifyPwd.Size = new System.Drawing.Size(73, 22);
            this.btModifyPwd.Text = "修改密码";
            this.btModifyPwd.Click += new System.EventHandler(this.btModifyPwd_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btActiveUser
            // 
            this.btActiveUser.Image = ((System.Drawing.Image)(resources.GetObject("btActiveUser.Image")));
            this.btActiveUser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btActiveUser.Name = "btActiveUser";
            this.btActiveUser.Size = new System.Drawing.Size(73, 22);
            this.btActiveUser.Text = "激活用户";
            this.btActiveUser.Click += new System.EventHandler(this.btActiveUser_Click);
            // 
            // btDeleteUser
            // 
            this.btDeleteUser.Image = ((System.Drawing.Image)(resources.GetObject("btDeleteUser.Image")));
            this.btDeleteUser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btDeleteUser.Name = "btDeleteUser";
            this.btDeleteUser.Size = new System.Drawing.Size(73, 22);
            this.btDeleteUser.Text = "删除用户";
            this.btDeleteUser.Click += new System.EventHandler(this.btDeleteUser_Click);
            // 
            // btModifyAuth
            // 
            this.btModifyAuth.Image = ((System.Drawing.Image)(resources.GetObject("btModifyAuth.Image")));
            this.btModifyAuth.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btModifyAuth.Name = "btModifyAuth";
            this.btModifyAuth.Size = new System.Drawing.Size(73, 22);
            this.btModifyAuth.Text = "修改权限";
            this.btModifyAuth.Click += new System.EventHandler(this.btModifyAuth_Click);
            // 
            // btModifyRole
            // 
            this.btModifyRole.Image = ((System.Drawing.Image)(resources.GetObject("btModifyRole.Image")));
            this.btModifyRole.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btModifyRole.Name = "btModifyRole";
            this.btModifyRole.Size = new System.Drawing.Size(73, 22);
            this.btModifyRole.Text = "更改角色";
            this.btModifyRole.Click += new System.EventHandler(this.btModifyRole_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btExit
            // 
            this.btExit.Image = ((System.Drawing.Image)(resources.GetObject("btExit.Image")));
            this.btExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(49, 22);
            this.btExit.Text = "退出";
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 59);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tvUsers);
            this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dgvAuthority);
            this.splitContainer1.Panel2.Controls.Add(this.lblAuthTitle);
            this.splitContainer1.Size = new System.Drawing.Size(650, 406);
            this.splitContainer1.SplitterDistance = 164;
            this.splitContainer1.SplitterWidth = 2;
            this.splitContainer1.TabIndex = 3;
            // 
            // tvUsers
            // 
            this.tvUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvUsers.ImageIndex = 0;
            this.tvUsers.ImageList = this.imageList1;
            this.tvUsers.Location = new System.Drawing.Point(2, 0);
            this.tvUsers.Name = "tvUsers";
            this.tvUsers.SelectedImageIndex = 0;
            this.tvUsers.Size = new System.Drawing.Size(162, 406);
            this.tvUsers.TabIndex = 9;
            this.tvUsers.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvUsers_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "users.ico");
            this.imageList1.Images.SetKeyName(1, "user.ico");
            // 
            // dgvAuthority
            // 
            this.dgvAuthority.AllowUserToResizeColumns = false;
            this.dgvAuthority.AllowUserToResizeRows = false;
            this.dgvAuthority.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAuthority.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvAuthority.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAuthority.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvAuthority.ColumnHeadersHeight = 29;
            this.dgvAuthority.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnID,
            this.ColumnAuthority,
            this.ColumnFunction,
            this.ColumnOperate,
            this.ColumnDescription,
            this.ColumnIsPermit});
            this.dgvAuthority.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAuthority.Location = new System.Drawing.Point(0, 25);
            this.dgvAuthority.Name = "dgvAuthority";
            this.dgvAuthority.ReadOnly = true;
            this.dgvAuthority.RowHeadersVisible = false;
            this.dgvAuthority.RowTemplate.Height = 25;
            this.dgvAuthority.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAuthority.Size = new System.Drawing.Size(484, 381);
            this.dgvAuthority.TabIndex = 6;
            // 
            // ColumnID
            // 
            this.ColumnID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnID.DataPropertyName = "ID";
            this.ColumnID.HeaderText = "ID";
            this.ColumnID.Name = "ColumnID";
            this.ColumnID.ReadOnly = true;
            this.ColumnID.Visible = false;
            // 
            // ColumnAuthority
            // 
            this.ColumnAuthority.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnAuthority.DataPropertyName = "Authority";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Red;
            this.ColumnAuthority.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnAuthority.FillWeight = 23F;
            this.ColumnAuthority.HeaderText = "权限";
            this.ColumnAuthority.Name = "ColumnAuthority";
            this.ColumnAuthority.ReadOnly = true;
            this.ColumnAuthority.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnFunction
            // 
            this.ColumnFunction.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnFunction.DataPropertyName = "Function";
            this.ColumnFunction.FillWeight = 50F;
            this.ColumnFunction.HeaderText = "功能模块";
            this.ColumnFunction.Name = "ColumnFunction";
            this.ColumnFunction.ReadOnly = true;
            this.ColumnFunction.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnOperate
            // 
            this.ColumnOperate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnOperate.DataPropertyName = "Operate";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ColumnOperate.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnOperate.FillWeight = 25F;
            this.ColumnOperate.HeaderText = "操作";
            this.ColumnOperate.Name = "ColumnOperate";
            this.ColumnOperate.ReadOnly = true;
            this.ColumnOperate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnDescription
            // 
            this.ColumnDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnDescription.DataPropertyName = "Description";
            this.ColumnDescription.FillWeight = 200F;
            this.ColumnDescription.HeaderText = "描述";
            this.ColumnDescription.Name = "ColumnDescription";
            this.ColumnDescription.ReadOnly = true;
            this.ColumnDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnIsPermit
            // 
            this.ColumnIsPermit.DataPropertyName = "IsPermit";
            this.ColumnIsPermit.HeaderText = "允许";
            this.ColumnIsPermit.Name = "ColumnIsPermit";
            this.ColumnIsPermit.ReadOnly = true;
            this.ColumnIsPermit.Visible = false;
            // 
            // lblAuthTitle
            // 
            this.lblAuthTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblAuthTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblAuthTitle.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblAuthTitle.ForeColor = System.Drawing.Color.White;
            this.lblAuthTitle.Location = new System.Drawing.Point(0, 0);
            this.lblAuthTitle.Name = "lblAuthTitle";
            this.lblAuthTitle.Size = new System.Drawing.Size(484, 25);
            this.lblAuthTitle.TabIndex = 5;
            this.lblAuthTitle.Text = "权限";
            this.lblAuthTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UsersFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 465);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "UsersFrm";
            this.Text = "用户权限管理";
            this.Load += new System.EventHandler(this.UsersFrm_Load);
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuthority)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dgvAuthority;
        private System.Windows.Forms.Label lblAuthTitle;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripButton btActiveUser;
        private System.Windows.Forms.ToolStripButton btDeleteUser;
        private System.Windows.Forms.ToolStripButton btModifyRole;
        private System.Windows.Forms.ToolStripButton btModifyPwd;
        private System.Windows.Forms.ToolStripButton btModifyAuth;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btExit;
        private System.Windows.Forms.TreeView tvUsers;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnAuthority;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnFunction;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnOperate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDescription;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColumnIsPermit;
    }
}