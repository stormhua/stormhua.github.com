using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachManageSystem.BLL;
using TeachManageSystem.Model;

namespace TeachManageSystem
{
    public partial class PasswordFrm : Form
    {
        private UsersInfo _user;
        private UsersBll _userBll=new UsersBll();

        public PasswordFrm()
        {
            InitializeComponent();
        }

        public PasswordFrm(UsersInfo user)
        {
            InitializeComponent();
            _user = user;
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (!_userBll.ComparePasswords(_user.Password, tbOldPwd.Text))
            {
                MessageBox.Show("ԭ���벻ƥ�䣡");
                return;
            }

            if (tbNewPwd.Text != tbConPwd.Text)
            {
                MessageBox.Show("��������������벻��ͬ��");
                return;
            }

            //���û���������޸�
            _user.Password = _userBll.CreateDbPassword(tbNewPwd.Text);
            string message = "";
            if( _userBll.UpdateUsers(_user, out message) > 0 )
                this.Close();
            MessageBox.Show(message);
        }
    }
}