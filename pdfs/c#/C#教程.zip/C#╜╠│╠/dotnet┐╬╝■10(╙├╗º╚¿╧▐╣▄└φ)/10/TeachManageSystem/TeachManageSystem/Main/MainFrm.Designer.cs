﻿namespace TeachManageSystem
{
    partial class MainFrm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.资料管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miTeacherInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.miStudentInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.miCourseInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.教学管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教学任务分配ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教学计划ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.考试成绩管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miAuthority = new System.Windows.Forms.ToolStripMenuItem();
            this.miLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.数据备份ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.使用指南ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.资料管理ToolStripMenuItem,
            this.教学管理ToolStripMenuItem,
            this.系统管理ToolStripMenuItem,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(792, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 资料管理ToolStripMenuItem
            // 
            this.资料管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miTeacherInfo,
            this.miStudentInfo,
            this.miCourseInfo});
            this.资料管理ToolStripMenuItem.Name = "资料管理ToolStripMenuItem";
            this.资料管理ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.资料管理ToolStripMenuItem.Text = "资料管理";
            // 
            // miTeacherInfo
            // 
            this.miTeacherInfo.Name = "miTeacherInfo";
            this.miTeacherInfo.Size = new System.Drawing.Size(142, 22);
            this.miTeacherInfo.Text = "教师资料管理";
            this.miTeacherInfo.Click += new System.EventHandler(this.miTeacherInfo_Click);
            // 
            // miStudentInfo
            // 
            this.miStudentInfo.Name = "miStudentInfo";
            this.miStudentInfo.Size = new System.Drawing.Size(142, 22);
            this.miStudentInfo.Text = "学生资料管理";
            this.miStudentInfo.Click += new System.EventHandler(this.miStudentInfo_Click);
            // 
            // miCourseInfo
            // 
            this.miCourseInfo.Name = "miCourseInfo";
            this.miCourseInfo.Size = new System.Drawing.Size(142, 22);
            this.miCourseInfo.Text = "课程资料管理";
            // 
            // 教学管理ToolStripMenuItem
            // 
            this.教学管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.教学任务分配ToolStripMenuItem,
            this.教学计划ToolStripMenuItem,
            this.考试成绩管理ToolStripMenuItem});
            this.教学管理ToolStripMenuItem.Name = "教学管理ToolStripMenuItem";
            this.教学管理ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.教学管理ToolStripMenuItem.Text = "教学管理";
            // 
            // 教学任务分配ToolStripMenuItem
            // 
            this.教学任务分配ToolStripMenuItem.Name = "教学任务分配ToolStripMenuItem";
            this.教学任务分配ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.教学任务分配ToolStripMenuItem.Text = "教学任务分配";
            // 
            // 教学计划ToolStripMenuItem
            // 
            this.教学计划ToolStripMenuItem.Name = "教学计划ToolStripMenuItem";
            this.教学计划ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.教学计划ToolStripMenuItem.Text = "教学计划安排";
            // 
            // 考试成绩管理ToolStripMenuItem
            // 
            this.考试成绩管理ToolStripMenuItem.Name = "考试成绩管理ToolStripMenuItem";
            this.考试成绩管理ToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.考试成绩管理ToolStripMenuItem.Text = "考试成绩管理";
            // 
            // 系统管理ToolStripMenuItem
            // 
            this.系统管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miAuthority,
            this.miLogout,
            this.toolStripSeparator1,
            this.数据备份ToolStripMenuItem});
            this.系统管理ToolStripMenuItem.Name = "系统管理ToolStripMenuItem";
            this.系统管理ToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.系统管理ToolStripMenuItem.Text = "系统管理";
            // 
            // miAuthority
            // 
            this.miAuthority.Name = "miAuthority";
            this.miAuthority.Size = new System.Drawing.Size(152, 22);
            this.miAuthority.Text = "用户权限管理";
            this.miAuthority.Click += new System.EventHandler(this.miAuthority_Click);
            // 
            // miLogout
            // 
            this.miLogout.Name = "miLogout";
            this.miLogout.Size = new System.Drawing.Size(152, 22);
            this.miLogout.Text = "注销";
            this.miLogout.Click += new System.EventHandler(this.miLogout_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // 数据备份ToolStripMenuItem
            // 
            this.数据备份ToolStripMenuItem.Name = "数据备份ToolStripMenuItem";
            this.数据备份ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.数据备份ToolStripMenuItem.Text = "数据备份";
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.使用指南ToolStripMenuItem,
            this.关于ToolStripMenuItem});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 使用指南ToolStripMenuItem
            // 
            this.使用指南ToolStripMenuItem.Name = "使用指南ToolStripMenuItem";
            this.使用指南ToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.使用指南ToolStripMenuItem.Text = "使用指南";
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.关于ToolStripMenuItem.Text = "关于...";
            // 
            // MainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "MainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "高校教学管理系统";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 资料管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教学管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 系统管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miTeacherInfo;
        private System.Windows.Forms.ToolStripMenuItem miStudentInfo;
        private System.Windows.Forms.ToolStripMenuItem miCourseInfo;
        private System.Windows.Forms.ToolStripMenuItem 教学任务分配ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教学计划ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 考试成绩管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miAuthority;
        private System.Windows.Forms.ToolStripMenuItem 数据备份ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 使用指南ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miLogout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}

