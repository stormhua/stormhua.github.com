using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachManageSystem.BLL;
using TeachManageSystem.Model;

namespace TeachManageSystem
{
    public partial class AuthorityFrm : Form
    {
        private UsersInfo _user = null;
        private RolesInfo _role = null;
        private string _title = "";

        public AuthorityFrm()
        {
            InitializeComponent();
        }

        public AuthorityFrm(UsersInfo user)
        {
            InitializeComponent();
            _user = user;
            _title = _user.Person.Name + string.Format("��{0}��", _user.Role.RoleName);
        }

        public AuthorityFrm(RolesInfo role)
        {
            InitializeComponent();
            _role = role;
            _title = _role.RoleName;
        }
        
        /// <summary>
        /// ��ʼ���������
        /// </summary>
        private void AuthorityFrm_Load(object sender, EventArgs e)
        {
            AdjustColumnOrder();
            lblAuthTitle.Text = _title;

            if( _user != null )
                DisplayAuthority(_user.Authority);
            else if( _role != null )
                DisplayAuthority(_role.Authority);
        }

        /// <summary>
        /// DataGridView�ؼ����ֶ�����˳��
        /// </summary>
        private void AdjustColumnOrder()
        {
            dgvAuthority.Columns["ColumnID"].Visible = false;
            dgvAuthority.Columns["ColumnAuthority"].DisplayIndex = 0;
            dgvAuthority.Columns["ColumnFunction"].DisplayIndex = 1;
            dgvAuthority.Columns["ColumnOperate"].DisplayIndex = 2;
            dgvAuthority.Columns["ColumnDescription"].DisplayIndex = 3;
        }

        /// <summary>
        /// ����Ȩ��״̬
        /// </summary>
        /// <param name="strAuth">Ȩ���ַ���</param>
        private void DisplayAuthority(string strAuth)
        {
            IList<AuthoritiesInfo> authorities = (new AuthoritiesBll()).GetAuthorities(strAuth, true);
            dgvAuthority.DataSource = authorities;
            foreach (DataGridViewRow row in dgvAuthority.Rows)
            {
                DataGridViewCheckBoxCell cell = (DataGridViewCheckBoxCell)row.Cells["ColumnAuthority"];                
                switch ( cell.Value.ToString() )
                {
                    case "-1":
                        cell.ReadOnly = true;
                        cell.ThreeState = true;
                        break;
                    case "0": 
                        cell.ReadOnly = false;
                        cell.ThreeState = false;
                        break;
                    case "1": 
                        cell.ReadOnly = false;
                        cell.ThreeState = false;
                        break;
                    default: break;
                }
            }
        }

        /// <summary>
        /// �رյ�ǰ����
        /// </summary>
        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// ��ԭ��Ĭ��ֵ
        /// </summary>
        private void btDefault_Click(object sender, EventArgs e)
        {
            if (_user != null)
                DisplayAuthority(_user.Authority);
            else if (_role != null)
                DisplayAuthority(_role.Authority);
        }

        /// <summary>
        /// ����
        /// </summary>
        private void btSave_Click(object sender, EventArgs e)
        {
            if (_user != null)//�����û�Ȩ��
            {
                _user.Authority = GetAuthority();
                string message="";
                (new UsersBll()).UpdateUsers(_user, out message);
                MessageBox.Show(message);
            }
            else if (_role != null)//�����ɫȨ��
            {
                _role.Authority = GetAuthority();
                string message = "";
                (new RolesBll()).UpdateRoles(_role, out message);
                MessageBox.Show(message);
            }

        }

        /// <summary>
        /// ��DataGridView�ؼ���ȡ��Ȩ���ַ���
        /// </summary>
        /// <returns></returns>
        private string GetAuthority()
        {
            dgvAuthority.EndEdit();
            StringBuilder authority = new StringBuilder();
            foreach (DataGridViewRow row in dgvAuthority.Rows)
            {
                if (row.Index > 0)
                    authority.Append(";");
                authority.Append(((DataGridViewCheckBoxCell)row.Cells["ColumnAuthority"]).Value.ToString());
            }
            return authority.ToString();
        }
    }
}