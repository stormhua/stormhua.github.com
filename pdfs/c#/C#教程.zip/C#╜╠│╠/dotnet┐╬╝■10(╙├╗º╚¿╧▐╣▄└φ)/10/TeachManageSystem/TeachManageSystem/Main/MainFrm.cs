﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace TeachManageSystem
{
    public partial class MainFrm : Form
    {
        public MainFrm()
        {
            InitializeComponent();
        }

        ///// <summary>
        ///// 设置子窗体的尺寸
        ///// </summary>
        ///// <param name="childFrm"></param>
        //public void ReSize(Form childFrm)
        //{
        //    childFrm.Height = this.ClientRectangle.Height - 50;//-28;
        //    childFrm.Width = this.ClientRectangle.Width - 6;
        //}

        /// <summary>
        /// 子窗口是否存在
        /// </summary>
        /// <param name="childFrmName"></param>
        public Form IsExist(string childFrmName)
        {
            foreach (Form childFrm in this.MdiChildren)
            {
                if (childFrm.Name == childFrmName)
                {
                    childFrm.Activate();
                    return childFrm;
                }
            }
            return null;
        }

        /// <summary>
        /// 显示子窗口，如果子窗口已经打开一次了，就将该窗口激活，否则创建一个新的子窗口。
        /// </summary>
        /// <param name="childFrmName">子窗口类型名字</param>
        public void ShowChildForm(string childFrmName)
        {
            if (IsExist(childFrmName) != null)
                return;
            //通过反射来生成子窗体对象
            Form form = (Form)Assembly.Load("TeachManageSystem").CreateInstance("TeachManageSystem."+childFrmName);
            form.MdiParent = this;
            form.WindowState = FormWindowState.Maximized;
            form.Show();
            //ReSize(form);
        }

        private void miStudentInfo_Click(object sender, EventArgs e)
        {
            ShowChildForm("StudentFrm");
        }

        private void miTeacherInfo_Click(object sender, EventArgs e)
        {
            ShowChildForm("TeacherFrm");
        }

        private void miAuthority_Click(object sender, EventArgs e)
        {
            ShowChildForm("UsersFrm");
        }

        /// <summary>
        /// 注销，更换登录用户
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void miLogout_Click(object sender, EventArgs e)
        {
            //关闭所有子窗口
            foreach (Form childFrm in this.MdiChildren)
            {
                childFrm.Close();
            }

            //注销，更改用户
            LoginFrm.LoginSuccess = false;
            LoginFrm login = new LoginFrm();
            login.ShowDialog();

            //如果选择退出，则关闭主窗口
            if (!LoginFrm.LoginSuccess)
                this.Close();
        }
    }
}