using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachManageSystem.Model;
using TeachManageSystem.BLL;

namespace TeachManageSystem
{
    public partial class TeacherInfoFrm : Form
    {
        /// <summary>
        /// ��������ʾ�Ľ�ʦ����
        /// </summary>
        private TeachersInfo _info = null;

        /// <summary>
        /// ���캯�������ӣ�
        /// </summary>
        public TeacherInfoFrm()
        {
            InitializeComponent();
            this.Text = "������ʦ����";
            Clear();
            
        }

        /// <summary>
        /// ���캯�����޸ģ�
        /// </summary>
        /// <param name="info"></param>
        public TeacherInfoFrm(TeachersInfo info)
        {
            InitializeComponent();
            this.Text = "�޸Ľ�ʦ����";
            _info = info;
            tbNumber.Text = info.Number;
            tbName.Text = info.Name;
            rbMan.Checked = info.Sex == "��" ? true : false;
            rbWoman.Checked = info.Sex == "Ů" ? true : false;
            cbJobTitle.Text = info.JobTitle;
            cbHeadship.Text = info.Headship;
        }

        /// <summary>
        /// ������пؼ�
        /// </summary>
        private void Clear()
        {
            tbNumber.Text = "";
            tbName.Text = "";
            rbMan.Checked = true;
            cbJobTitle.SelectedIndex = 0;
            cbHeadship.SelectedIndex = 0;
        }

        private void tsbSave_Click(object sender, EventArgs e)
        {
            //�����û���д����Ϣ������һ����ʦ���ϵĶ���     
            if (_info == null)
                _info = new TeachersInfo();

            _info.Number = tbNumber.Text;
            _info.Name = tbName.Text;
            if (rbMan.Checked)
                _info.Sex = rbMan.Text;
            else
                _info.Sex = rbWoman.Text;
            _info.JobTitle = cbJobTitle.Text;
            _info.Headship = cbHeadship.Text;

            //���ڱ�������ʱ�ķ�����Ϣ
            string message = "";

            if (_info.ID > 0)
            {
                //�޸�����
                (new TeachersBll()).UpdateTeachers(_info, out message);
            }
            else
            {
                //��������
                int iReturn = (new TeachersBll()).InsertTeachers(_info, out message);
                if (iReturn > 0)
                {
                    Clear();
                }
            }

            //��ʾ��ʾ��Ϣ
            MessageBox.Show(message);
        }

        private void tsbCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}