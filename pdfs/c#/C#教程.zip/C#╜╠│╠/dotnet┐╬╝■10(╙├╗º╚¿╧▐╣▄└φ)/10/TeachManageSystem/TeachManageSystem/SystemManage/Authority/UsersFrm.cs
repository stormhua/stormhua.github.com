using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TeachManageSystem.BLL;
using TeachManageSystem.Model;

namespace TeachManageSystem
{
    public partial class UsersFrm : Form
    {
        private AuthoritiesBll _authoritiesBll = new AuthoritiesBll();
        private RolesBll _rolesBll = new RolesBll();
        private UsersBll _usersBll = new UsersBll();

        public UsersFrm()
        {
            InitializeComponent();
        }

        private void UsersFrm_Load(object sender, EventArgs e)
        {
            SetAuthority();
            InitTree();
            AdjustColumnOrder();
            //authorityControl1.SetAuthority("1;0;1;0;1;0;1;0;1;0;1;1;0;1;-1;-1;-1", true);
            //authorityControl1.Visible = true;
        }

        /// <summary>
        /// ����Ȩ��
        /// </summary>
        private void SetAuthority()
        {
            btActiveUser.Enabled = LoginFrm.CurrentUser.Authorities[14].IsPermit;
            btDeleteUser.Enabled = LoginFrm.CurrentUser.Authorities[14].IsPermit;
            btModifyAuth.Enabled = LoginFrm.CurrentUser.Authorities[14].IsPermit;
            btModifyRole.Enabled = LoginFrm.CurrentUser.Authorities[14].IsPermit;
        }

        /// <summary>
        /// DataGridView�ؼ����ֶ�����˳��
        /// </summary>
        private void AdjustColumnOrder()
        {
            dgvAuthority.Columns["ColumnID"].Visible = false;
            dgvAuthority.Columns["ColumnAuthority"].DisplayIndex = 0;
            dgvAuthority.Columns["ColumnFunction"].DisplayIndex = 1;
            dgvAuthority.Columns["ColumnOperate"].DisplayIndex = 2;
            dgvAuthority.Columns["ColumnDescription"].DisplayIndex = 3;

            dgvAuthority.DataSource = _authoritiesBll.GetAuthoritiesAllData();
        }

        /// <summary>
        /// ��ʼ�����ؼ��Ľڵ�
        /// </summary>
        private void InitTree()
        {
            //����������ڵ�
            tvUsers.Nodes.Clear();
            if (LoginFrm.CurrentUser.Authorities[14].IsPermit)//ӵ���û�Ȩ�޵Ļ������Զ������û����й���
            {
                //�󶨵�һ���ڵ㣨��ɫ��
                IList<RolesInfo> infoRoles = _rolesBll.GetRolesAllData();
                tvUsers.Nodes.Clear();
                foreach (RolesInfo info in infoRoles)
                {
                    TreeNode tn = new TreeNode(info.RoleName);
                    tn.Tag = info;
                    tn.ImageIndex = 0;
                    tn.SelectedImageIndex = 0;
                    tvUsers.Nodes.Add(tn);
                }

                //�󶨵ڶ����ڵ㣨�û���
                IList<UsersInfo> infoUsers = _usersBll.GetUsersAllData();
                foreach (UsersInfo info in infoUsers)
                {
                    info.Role = tvUsers.Nodes[info.Role.ID].Tag as RolesInfo;//���û��Ľ�ɫ���԰󶨸��׽ڵ�Ľ�ɫ����

                    TreeNode tn = new TreeNode(info.Person.Name); 
                    tn.Tag = info;
                    tn.ImageIndex = 1;
                    tn.SelectedImageIndex = 1;
                    tvUsers.Nodes[info.Role.ID].Nodes.Add(tn);                    
                }
            }
            else//û���û�Ȩ�޹�����Ȩ�ޣ���ֻ�ܿ����Լ�
            {
                TreeNode tn = new TreeNode(LoginFrm.CurrentUser.Role.RoleName);
                tn.Tag = LoginFrm.CurrentUser.Role;
                tn.ImageIndex = 0;
                tn.SelectedImageIndex = 0;
                tvUsers.Nodes.Add(tn);
                tn = new TreeNode(LoginFrm.CurrentUser.Person.Name);
                tn.Tag = LoginFrm.CurrentUser;
                tn.ImageIndex = 1;
                tn.SelectedImageIndex = 1;
                tvUsers.Nodes[0].Nodes.Add(tn);
            }

            //�����ؼ������нڵ�չ��
            tvUsers.ExpandAll();
        }

        /// <summary>
        /// ѡ�����ڵ�ʱ�������¼�
        /// </summary>
        private void tvUsers_AfterSelect(object sender, TreeViewEventArgs e)
        {
            DisplayAuthority(e.Node);
        }

        /// <summary>
        /// ��ʾ��ѡ�ڵ��Ȩ��
        /// </summary>
        /// <param name="node">���ڵ�</param>
        private void DisplayAuthority(TreeNode node)
        {
            switch (node.Level)
            {
                case 0:
                    lblAuthTitle.Text = string.Format("��ɫȨ�ޣ�{0}��", ((RolesInfo)node.Tag).RoleName);
                    dgvAuthority.DataSource = _authoritiesBll.GetAuthorities(((RolesInfo)node.Tag).Authority, false);
                    break;
                case 1:
                    lblAuthTitle.Text = string.Format("�û�Ȩ�ޣ�{0}��", ((UsersInfo)node.Tag).Person.Name);
                    dgvAuthority.DataSource = _authoritiesBll.GetAuthorities(((UsersInfo)node.Tag).Authority, false);
                    break;
                default: break;
            }
        }

        /// <summary>
        /// �����û���ť�¼�
        /// </summary>
        private void btActiveUser_Click(object sender, EventArgs e)
        {
            ActiveUserFrm form = new ActiveUserFrm();
            form.ShowDialog();
            InitTree();
        }

        /// <summary>
        /// ɾ���û���ť�¼�
        /// </summary>
        private void btDeleteUser_Click(object sender, EventArgs e)
        {
            if (!IsSelectNode())
                return;
            if (tvUsers.SelectedNode.Level == 0)
                MessageBox.Show("����ɾ���û���ɫ��");
            else
            {                
                string message = "";
                int returnValue = _usersBll.DeleteUsers(((UsersInfo)tvUsers.SelectedNode.Tag).ID, out message);
                MessageBox.Show(message);
                if (returnValue > 0)
                    tvUsers.SelectedNode.Remove();
            }
        }

        /// <summary>
        /// �˳���ť�¼�
        /// </summary>
        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// �޸�Ȩ�ް�ť���¼�
        /// </summary>
        private void btModifyAuth_Click(object sender, EventArgs e)
        {
            AuthorityFrm form;
            if (!IsSelectNode())
                return;
            if( tvUsers.SelectedNode.Level == 0 )
                form = new AuthorityFrm(tvUsers.SelectedNode.Tag as RolesInfo);
            else
                form = new AuthorityFrm(tvUsers.SelectedNode.Tag as UsersInfo);
            form.ShowDialog();

            //������ʾ��ѡ�ڵ��Ȩ��
            DisplayAuthority(tvUsers.SelectedNode);
        }

        /// <summary>
        /// �Ƿ�ѡ����ĳ�����ؼ��ڵ�
        /// </summary>
        /// <returns>ѡ�У�true����ûѡ�У�false��</returns>
        private bool IsSelectNode()
        {
            if (tvUsers.SelectedNode == null)
            {
                MessageBox.Show("����ѡ��һ���ڵ㣡");
                return false;
            }
            return true;
        }

        /// <summary>
        /// �޸��û�������¼�
        /// </summary>
        private void btModifyPwd_Click(object sender, EventArgs e)
        {
            if (IsSelectNode())
            {
                if (tvUsers.SelectedNode.Level == 0)
                    MessageBox.Show("ֻ���û������޸����룡");
                else
                {
                    (new PasswordFrm(tvUsers.SelectedNode.Tag as UsersInfo)).ShowDialog();
                }
            }
        }

        /// <summary>
        /// �޸��û�������ɫ
        /// </summary>
        private void btModifyRole_Click(object sender, EventArgs e)
        {
            if (IsSelectNode())
            {
                if (tvUsers.SelectedNode.Level == 0)
                    MessageBox.Show("ֻ���û������޸�������ɫ��");
                else
                {
                    (new RoleSelectFrm(tvUsers.SelectedNode.Tag as UsersInfo)).ShowDialog();

                    //ˢ����
                    InitTree();
                }
            }
        }
    }
}