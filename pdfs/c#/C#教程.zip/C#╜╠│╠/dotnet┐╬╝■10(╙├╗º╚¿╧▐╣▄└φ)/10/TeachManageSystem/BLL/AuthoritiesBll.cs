﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Data;
using System.Collections;
using TeachManageSystem.Model;
using TeachManageSystem.DAL;

namespace TeachManageSystem.BLL
{
    public class AuthoritiesBll
    {
        private static readonly Authorities info = new Authorities();

        /// <summary>
        /// 通过条件读取一条数据，返回值为该表的实体
        /// </summary>
        /// <param name='WhereSentence'>过滤条件</param>
        /// <returns></returns>
        public AuthoritiesInfo GetAuthoritiesData(string WhereSentence)
        {
            return info.GetAuthoritiesData(WhereSentence);
        }
        /// <summary>
        /// 读取所有的数据,返回IList
        /// </summary>
        /// <returns>返回所有的数据的对象</returns>
        public IList<AuthoritiesInfo> GetAuthoritiesAllData()
        {
            return info.GetAuthoritiesAllData();
        }
        /// <summary>
        /// 通过条件读取数据，返回IList
        /// </summary>
        /// <param name='WhereSentence'>过滤条件</param>
        /// <returns>返回某一行数据</returns>
        public IList<AuthoritiesInfo> GetAuthoritiesDataID(string WhereSentence)
        {
            return info.GetAuthoritiesDataID(WhereSentence);
        }

        /// <summary>
        /// 设置权限
        /// </summary>
        /// <param name="authority">权限字符串</param>
        /// <param name="enabled">可修改</param>
        /// <returns>设置了权限的列表</returns>
        public IList<AuthoritiesInfo> GetAuthorities(string authority,bool enabled)
        {
            IList<AuthoritiesInfo> infoes = info.GetAuthoritiesAllData();

            string[] strAuth = authority.Split(';');

            if (infoes.Count != strAuth.Length)
                return null;

            for (int i = 0; i < strAuth.Length; i++)
            {
                switch (strAuth[i])
                {
                    case "-1":
                        infoes[i].Authority = enabled ? "-1" : "";
                        infoes[i].IsPermit = false;
                        break;
                    case "0":
                        infoes[i].Authority = enabled ? "0" : "";
                        infoes[i].IsPermit = false;
                        break;
                    case "1":
                        infoes[i].Authority = enabled ? "1" : "√";
                        infoes[i].IsPermit = true;
                        break;
                    default: break;
                }
            }
            return infoes;
        }
    }
}
