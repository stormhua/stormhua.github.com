﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Data;
using System.Collections;
using TeachManageSystem.Model;
using TeachManageSystem.DAL;

namespace TeachManageSystem.BLL
{
    public class TeachersBll
    {
        //private static readonly ITeachers info = (ITeachers)Assembly.Load("SQLServerDAL").CreateInstance("TeachManageSystem.SQLServerDAL.Teachers");
        private static readonly Teachers info = new Teachers();
        private static readonly UsersBll user = new UsersBll();

        /// <summary>
        /// 通过条件读取一条数据，返回值为该表的实体
        /// </summary>
        /// <param name='WhereSentence'>过滤条件</param>
        /// <returns></returns>
        public TeachersInfo GetTeachersData(string WhereSentence)
        {
            return info.GetTeachersData(WhereSentence);
        }
        /// <summary>
        /// 读取所有的数据,返回IList
        /// </summary>
        /// <returns>返回所有的数据的对象</returns>
        public IList<TeachersInfo> GetTeachersAllData()
        {
            return info.GetTeachersAllData();
        }

        /// <summary>
        /// 通过条件读取数据，返回IList
        /// </summary>
        /// <param name='WhereSentence'>过滤条件</param>
        /// <returns>返回某一行数据</returns>
        public IList<TeachersInfo> GetTeachersDataID(string WhereSentence)
        {
            return info.GetTeachersDataID(WhereSentence);
        }
        /// <summary>
        /// 插入表操作
        /// </summary>
        /// <param name='info'></param>
        public int InsertTeachers(TeachersInfo infos, out string message)
        {
            int ReturnValues = info.InsertTeachers(infos);
            switch (ReturnValues)
            {
                case -1: message = "工号已经存在！"; break;
                case 1: message = "添加成功！"; break;
                case 0: message = "添加时发生错误！"; break;
                default: message = "添加成功！"; break;
            }
            return ReturnValues;
        }
        /// <summary>
        /// 删除操作
        /// </summary>
        /// <param name='ID'></param>
        public int DeleteTeachers(int ID, out string message)
        {
            int ReturnValues = info.DeleteTeachers(ID);
            switch (ReturnValues)
            {
                case -1: message = "该记录不存在，不能删除！"; break;
                case 1: message = "删除成功！"; break;
                case 0: message = "删除时发生错误！"; break;
                default: message = "删除成功！"; break;
            }
            return ReturnValues;
        }
        /// <summary>
        /// 修改操作
        /// </summary>
        /// <param name='info'></param>
        public int UpdateTeachers(TeachersInfo infos, out string message)
        {
            int ReturnValues = info.UpdateTeachers(infos);
            switch (ReturnValues)
            {
                case -1: message = "该记录不存在，不能修改！"; break;
                case -2: message = "工号已经存在！请输入一个新的工号。"; break;
                case 1: message = "更新成功！"; break;
                case 0: message = "更新时发生错误！"; break;
                default: message = "更新成功！"; break;
            }
            return ReturnValues;
        }

        /// <summary>
        /// 得到所有教师及其激活状态
        /// </summary>
        /// <returns></returns>
        public IList<TeachersInfo> GetAllTeachersAndStatus()
        {
            IList<UsersInfo> users = user.GetUsersDataID("RoleID<3");
            IList<TeachersInfo> teachers = GetTeachersAllData();

            foreach (UsersInfo infoUser in users)
            {
                foreach (TeachersInfo infoTeacher in teachers)
                {
                    if (infoUser.Person.ID == infoTeacher.ID)
                    {
                        infoTeacher.IsActived = "√";
                        break;
                    }
                }
            }

            return teachers;
        }


    }
}
