﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Data;
using System.Collections;
using TeachManageSystem.Model;
using TeachManageSystem.DAL;

namespace TeachManageSystem.BLL
{
    public class RolesBll
    {        
        private static readonly Roles info = new Roles();

        /// <summary>
        /// 通过条件读取一条数据，返回值为该表的实体
        /// </summary>
        /// <param name='WhereSentence'>过滤条件</param>
        /// <returns></returns>
        public RolesInfo GetRolesData(string WhereSentence)
        {
            return info.GetRolesData(WhereSentence);
        }
        /// <summary>
        /// 读取所有的数据,返回IList
        /// </summary>
        /// <returns>返回所有的数据的对象</returns>
        public IList<RolesInfo> GetRolesAllData()
        {
            return info.GetRolesAllData();
        }
        /// <summary>
        /// 通过条件读取数据，返回IList
        /// </summary>
        /// <param name='WhereSentence'>过滤条件</param>
        /// <returns>返回某一行数据</returns>
        public IList<RolesInfo> GetRolesDataID(string WhereSentence)
        {
            return info.GetRolesDataID(WhereSentence);
        }
        ///// <summary>
        ///// 插入表操作
        ///// </summary>
        ///// <param name='info'></param>
        //public int InsertRoles(RolesInfo infos, out string message)
        //{
        //    int ReturnValues = info.InsertRoles(infos);
        //    switch (ReturnValues)
        //    {
        //        case -1: message = "已经存在！"; break;
        //        case 1: message = "添加成功！"; break;
        //        case 0: message = "添加时发生错误！"; break;
        //        default: message = "添加成功！"; break;
        //    }
        //    return ReturnValues;
        //}
        ///// <summary>
        ///// 删除操作
        ///// </summary>
        ///// <param name='ID'></param>
        //public int DeleteRoles(int ID, out string message)
        //{
        //    int ReturnValues = info.DeleteRoles(ID);
        //    switch (ReturnValues)
        //    {
        //        case -1: message = "该信息不存在！"; break;
        //        case 1: message = "删除成功！"; break;
        //        case 0: message = "删除时发生错误！"; break;
        //        default: message = "删除成功！"; break;
        //    }
        //    return ReturnValues;
        //}
        /// <summary>
        /// 修改操作
        /// </summary>
        /// <param name='info'></param>
        public int UpdateRoles(RolesInfo infos, out string message)
        {
            int ReturnValues = info.UpdateRoles(infos);
            switch (ReturnValues)
            {
                case -1: message = "该信息不存在！"; break;
                case 1: message = "更新成功！"; break;
                case 0: message = "更新时发生错误！"; break;
                default: message = "更新成功！"; break;
            }
            return ReturnValues;
        }
    }
}
