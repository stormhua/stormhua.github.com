﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AddUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlRole.DataSource = Roles.GetAllRoles();
            ddlRole.DataBind();
        }
    }
    protected void btAddUser_Click(object sender, EventArgs e)
    {
        MembershipCreateStatus status;
        Membership.CreateUser(tbUserName.Text, tbPwd.Text, tbEmail.Text, tbQuestion.Text,tbAnswer.Text, true, out status);
        switch (status)
        {
            case MembershipCreateStatus.Success:
                Response.Write("<script>alert('新用户创建成功.');</script>");
                Roles.AddUserToRole(tbUserName.Text, ddlRole.Text);
                break;
            case MembershipCreateStatus.InvalidUserName:
                Response.Write("<script>alert('无效的用户名.');</script>");
                break;
            case MembershipCreateStatus.DuplicateEmail:
                Response.Write("<script>alert('重复的电子邮件地址.');</script>");
                break;
            case MembershipCreateStatus.InvalidQuestion:
                Response.Write("<script>alert('无效的密码问题.');</script>");
                break;
            case MembershipCreateStatus.DuplicateUserName:
                Response.Write("<script>alert('重复的用户名.');</script>");
                break;
            case MembershipCreateStatus.InvalidAnswer:
                Response.Write("<script>alert('无效的密码答案.');</script>");
                break;
            case MembershipCreateStatus.InvalidEmail:
                Response.Write("<script>alert('无效的电子邮件地址.');</script>");
                break;
            case MembershipCreateStatus.InvalidPassword:
                Response.Write("<script>alert('无效的密码.');</script>");
                break;
            default:
                Response.Write("<script>alert('在创建用户过程中发生错误.');</script>");
                break;
        }
    }
}
