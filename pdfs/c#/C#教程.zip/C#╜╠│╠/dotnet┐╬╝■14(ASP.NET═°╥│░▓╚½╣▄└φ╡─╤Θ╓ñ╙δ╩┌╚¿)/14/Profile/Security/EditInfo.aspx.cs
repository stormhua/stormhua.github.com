﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Security_EditInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Profile.真实姓名 = TextBox1.Text;
        Profile.QQ号码 = TextBox2.Text;
        Profile.家庭地址.城市 = TextBox3.Text;
        Profile.家庭地址.邮编 = TextBox4.Text;
        Profile.Save();

        Response.Redirect("Infomation.aspx");
    }
}
