﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBBackup2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        #region 日志相关操作
        /// <summary>
        /// 查询得到所有备份还原日志
        /// </summary>
        /// <returns></returns>
        private DataSet GetBackupLog()
        {
            try
            {
                string strSQL = "Data Source=.\\SQL2000;Initial Catalog=Backup;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(strSQL);

                SqlCommand myCom = new SqlCommand();
                myCom.Connection = myCon;
                myCom.CommandText = "SELECT * FROM BackupLog";

                SqlDataAdapter myAdapter = new SqlDataAdapter();
                myAdapter.SelectCommand = myCom;

                DataSet ds = new DataSet();
                myAdapter.Fill(ds, "BackupLog");

                return ds;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 保存一条日志
        /// </summary>
        /// <param name="time">执行时间</param>
        /// <param name="type">执行类型</param>
        /// <param name="userName">执行用户</param>
        /// <param name="filePath">文件路径</param>
        /// <returns></returns>
        private int InsertBackupLog(DateTime time, string type, string userName, string filePath)
        {
            try
            {
                string strSQL = "Data Source=.\\SQL2000;Initial Catalog=Backup;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(strSQL);
                myCon.Open();

                SqlCommand myCom = new SqlCommand();
                myCom.Connection = myCon;
                myCom.CommandText = string.Format("INSERT INTO BackupLog([Time],Type,UserName,FilePath) VALUES('{0}','{1}','{2}','{3}')", time, type, userName, filePath);

                int row = myCom.ExecuteNonQuery();
                myCon.Close();
                return row;
            }
            catch
            {
                return 0;
            }
        }
        #endregion

        #region 数据库备份和还原、进度条
        private void Step(string message, int percent)
        {
            progressBar1.Value = percent;
        }

        /// <summary>
        /// 数据库的备份和实时进度显示代码：
        /// </summary>
        /// <param name="ServerName"></param>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <param name="strDbName"></param>
        /// <param name="strFileName"></param>
        /// <returns></returns>
        public bool BackupDB(string ServerName, string UserName, string Password, string strDbName, string strFileName)
        {
            SQLDMO.SQLServer svr = new SQLDMO.SQLServerClass();
            try
            {
                svr.Connect(ServerName, UserName, Password);
                SQLDMO.Backup bak = new SQLDMO.BackupClass();
                bak.Action = 0;
                bak.Initialize = true;
                SQLDMO.BackupSink_PercentCompleteEventHandler pceh = new SQLDMO.BackupSink_PercentCompleteEventHandler(Step);
                bak.PercentComplete += pceh;

                bak.Files = strFileName;
                bak.Database = strDbName;
                bak.SQLBackup(svr);

                return true;
            }
            catch (Exception err)
            {
                throw (new Exception("备份数据库失败" + err.Message));
                //return false ;
                //MessageBox.Show("备份数据库失败"+err.Message);
            }
            finally
            {
                svr.DisConnect();
            }
        }

        /// <summary>
        /// 数据库的恢复的代码：
        /// </summary>
        /// <param name="ServerName"></param>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <param name="strDbName"></param>
        /// <param name="strFileName"></param>
        /// <returns></returns>
        public bool RestoreDB(string ServerName, string UserName, string Password, string strDbName, string strFileName)
        {
            SQLDMO.SQLServer svr = new SQLDMO.SQLServerClass();
            try
            {
                svr.Connect(ServerName, UserName, Password);
                SQLDMO.QueryResults qr = svr.EnumProcesses(-1);
                int iColPIDNum = -1;
                int iColDbName = -1;
                for (int i = 1; i <= qr.Columns; i++)
                {
                    string strName = qr.get_ColumnName(i);
                    if (strName.ToUpper().Trim() == "SPID")
                    {
                        iColPIDNum = i;
                    }
                    else if (strName.ToUpper().Trim() == "DBNAME")
                    {
                        iColDbName = i;
                    }
                    if (iColPIDNum != -1 && iColDbName != -1)
                        break;
                }

                for (int i = 1; i <= qr.Rows; i++)
                {
                    int lPID = qr.GetColumnLong(i, iColPIDNum);
                    string strDBName = qr.GetColumnString(i, iColDbName);
                    if (strDBName.ToUpper() == strDbName.ToUpper())
                        svr.KillProcess(lPID);
                }


                SQLDMO.Restore res = new SQLDMO.RestoreClass();
                res.Action = 0;
                SQLDMO.RestoreSink_PercentCompleteEventHandler pceh = new SQLDMO.RestoreSink_PercentCompleteEventHandler(Step);
                res.PercentComplete += pceh;
                res.Files = strFileName;

                res.Database = strDbName;
                res.ReplaceDatabase = true;
                res.SQLRestore(svr);
                return true;
            }
            catch (Exception err)
            {
                throw (new Exception("恢复数据库失败,请关闭所有和该数据库连接的程序！" + err.Message));
                //return false ;
                //MessageBox.Show("恢复数据库失败,请关闭所有和该数据库连接的程序！"+err.Message);
            }
            finally
            {
                svr.DisConnect();
            }
        }
        #endregion

        /// <summary>
        /// 显示所有操作日志
        /// </summary>
        private void ShowLog()
        {
            dgvBackup.DataSource = GetBackupLog().Tables["BackupLog"];
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            ShowLog();
        }

        private void btBackup_Click(object sender, EventArgs e)
        {
            //设置保存文件对话框的属性
            saveFileDialog1.Filter = "Bak files (*.bak)|*.bak|All files(*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;

            //打开对话框，单击确定按钮
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (BackupDB(".\\SQL2000", "sa", "608", "BackupTest", saveFileDialog1.FileName))
                {
                    int returnRowCount = InsertBackupLog(DateTime.Now, "备份", "测试用户", saveFileDialog1.FileName);
                    if (returnRowCount > 0)
                    {
                        MessageBox.Show("备份成功！\n保存操作日志成功！");
                        ShowLog();
                    }
                }
            }
        }

        private void btRestore_Click(object sender, EventArgs e)
        {
            //设置打开文件对话框的属性
            openFileDialog1.Filter = "bak files (*.bak)|*.bak|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;

            //打开对话框，单击确定按钮
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (RestoreDB(".\\SQL2000", "sa", "608", "BackupTest", openFileDialog1.FileName))
                {
                    int returnRowCount = InsertBackupLog(DateTime.Now, "还原", "测试用户", openFileDialog1.FileName);
                    if (returnRowCount > 0)
                    {
                        MessageBox.Show("还原成功！\n保存操作日志成功！");
                        ShowLog();//显示所有操作日志
                    }
                }
            }
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}