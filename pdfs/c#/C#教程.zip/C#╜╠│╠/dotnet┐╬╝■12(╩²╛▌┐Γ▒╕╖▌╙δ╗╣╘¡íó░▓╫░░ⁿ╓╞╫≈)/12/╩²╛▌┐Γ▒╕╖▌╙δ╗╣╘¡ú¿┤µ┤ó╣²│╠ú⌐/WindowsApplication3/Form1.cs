using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region ��־��ز���
        /// <summary>
        /// ��ѯ�õ����б��ݻ�ԭ��־
        /// </summary>
        /// <returns></returns>
        private DataSet GetBackupLog()
        {
            try
            {
                string strSQL = "Data Source=.\\SQL2000;Initial Catalog=Backup;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(strSQL);

                SqlCommand myCom = new SqlCommand();
                myCom.Connection = myCon;
                myCom.CommandText = "SELECT * FROM BackupLog";

                SqlDataAdapter myAdapter = new SqlDataAdapter();
                myAdapter.SelectCommand = myCom;

                DataSet ds = new DataSet();
                myAdapter.Fill(ds, "BackupLog");

                return ds;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// ����һ����־
        /// </summary>
        /// <param name="time">ִ��ʱ��</param>
        /// <param name="type">ִ������</param>
        /// <param name="userName">ִ���û�</param>
        /// <param name="filePath">�ļ�·��</param>
        /// <returns></returns>
        private int InsertBackupLog(DateTime time,string type,string userName,string filePath )
        {
            try
            {
                string strSQL = "Data Source=.\\SQL2000;Initial Catalog=Backup;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(strSQL);
                myCon.Open();

                SqlCommand myCom = new SqlCommand();
                myCom.Connection = myCon;
                myCom.CommandText = string.Format("INSERT INTO BackupLog([Time],Type,UserName,FilePath) VALUES('{0}','{1}','{2}','{3}')",time,type,userName,filePath);

                int row = myCom.ExecuteNonQuery();
                myCon.Close();
                return row;
            }
            catch
            {
                return 0;
            }
        }
        #endregion

        #region ���ݻ�ԭ���ݿ��װ����
        /// <summary>
        /// �������ݿ�
        /// </summary>
        /// <param name="dbName">���ݿ�����</param>
        /// <param name="filePath">�ļ�·��</param>
        /// <param name="flag">0:���ݣ�1:��ԭ</param>
        /// <returns>0:ִ�гɹ�</returns>
        private int BackupDatabase(string dbName,string filePath,int flag)
        {
            try
            {
                string strSQL = "Data Source=.\\SQL2000;Initial Catalog=Backup;Integrated Security=True";
                SqlConnection myCon = new SqlConnection(strSQL);
                myCon.Open();

                SqlCommand myCom = new SqlCommand();
                myCom.Connection = myCon;
                myCom.CommandType = CommandType.StoredProcedure;
                myCom.CommandText = "BackupRestoreDB";

                myCom.Parameters.Add(new SqlParameter("@DBName", SqlDbType.VarChar, 20));
                myCom.Parameters.Add(new SqlParameter("@FilePath", SqlDbType.VarChar, 200));
                myCom.Parameters.Add(new SqlParameter("@Flag", SqlDbType.Int));
                myCom.Parameters.Add(new SqlParameter("ReturnValue",SqlDbType.Int,4,ParameterDirection.ReturnValue,false,0,0,string.Empty,DataRowVersion.Default,null));


                myCom.Parameters["@DBName"].Value = dbName;
                myCom.Parameters["@FilePath"].Value = filePath;
                myCom.Parameters["@Flag"].Value = flag;

                int row = myCom.ExecuteNonQuery();
                myCon.Close();
                return int.Parse(myCom.Parameters["ReturnValue"].Value.ToString());
            }
            catch
            {
                return -1;
            }
        }
        #endregion

        private void Form1_Load(object sender, EventArgs e)
        {
            ShowLog();
        }

        /// <summary>
        /// ��ʾ���в�����־
        /// </summary>
        private void ShowLog()
        {
            dgvBackup.DataSource = GetBackupLog().Tables["BackupLog"];
        }

        /// <summary>
        /// ���ݰ�ť�����¼�
        /// </summary>
        private void btBackup_Click(object sender, EventArgs e)
        {
            //���ñ����ļ��Ի��������
            saveFileDialog1.Filter = "bak files (*.bak)|*.bak|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;

            //�򿪶Ի��򣬵���ȷ����ť
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                int returnValue=-1;
                int returnRowCount=0;

                returnValue = BackupDatabase("BackupTest", saveFileDialog1.FileName, 0);
                //�������ֵΪ0����ʾ���ݿⱸ�ݳɹ�
                if (returnValue == 0)
                {
                    //������־�������صõ�Ӱ�������
                    returnRowCount = InsertBackupLog(DateTime.Now, "����", "�����û�", saveFileDialog1.FileName);
                }

                if ((returnValue == 0) && (returnRowCount > 0))
                {
                    MessageBox.Show("���ݳɹ���\n���������־�ɹ���");
                    ShowLog();//��ʾ���в�����־
                }
            }
            
        }

        /// <summary>
        /// ��ԭ��ť�����¼�
        /// </summary>
        private void btRestore_Click(object sender, EventArgs e)
        {
            //���ô��ļ��Ի��������
            openFileDialog1.Filter = "bak files (*.bak)|*.bak|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;

            //�򿪶Ի��򣬵���ȷ����ť
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                int returnValue = -1;
                int returnRowCount = 0;

                returnValue = BackupDatabase("BackupTest", openFileDialog1.FileName, 1);
                //�������ֵΪ0����ʾ���ݿ⻹ԭ�ɹ�
                if (returnValue == 0)
                {
                    //������־�������صõ�Ӱ�������
                    returnRowCount = InsertBackupLog(DateTime.Now, "��ԭ", "�����û�", openFileDialog1.FileName);
                }

                if ((returnValue == 0) && (returnRowCount > 0))
                {
                    MessageBox.Show("��ԭ�ɹ���\n���������־�ɹ���");
                    ShowLog();//��ʾ���в�����־
                }
            }
        }

        //�˳�
        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}