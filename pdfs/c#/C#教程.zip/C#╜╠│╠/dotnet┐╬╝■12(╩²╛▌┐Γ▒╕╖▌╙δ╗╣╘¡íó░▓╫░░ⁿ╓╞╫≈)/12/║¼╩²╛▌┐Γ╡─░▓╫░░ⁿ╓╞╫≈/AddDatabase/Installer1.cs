using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Data.SqlClient;

namespace AddDatabase
{
    [RunInstaller(true)]
    public partial class Installer1 : Installer
    {
        public Installer1()
        {
            InitializeComponent();
        }

        //ִ��SQL���
        private void ExecuteSql(string conn, string DataBaseName, string Sql)
        {
            SqlConnection mySqlConnection = new SqlConnection(conn);
            //			String ConnectionString = String.Format(
            //				"workstation id={0};packet size=4096;user id={1};data source={2};persist security info=False;initial catalog=master", 
            //				this.Context.Parameters["server"],
            //				this.Context.Parameters["user"],
            //				this.Context.Parameters["server"]);
            //			
            //			SqlConnection sqlConnection1 = new SqlConnection(ConnectionString);
            System.Data.SqlClient.SqlCommand Command = new System.Data.SqlClient.SqlCommand(Sql, mySqlConnection);
            Command.Connection.Open();
            Command.Connection.ChangeDatabase(DataBaseName);
            try
            {
                Command.ExecuteNonQuery();
            }
            finally
            {
                Command.Connection.Close();
            }
        }


        public override void Install(System.Collections.IDictionary stateSaver)
        {
            base.Install(stateSaver);

            //---------------------�������ַ���д��Ӧ�ó��������ļ�-----------------------------------
            try
            {
                System.IO.FileInfo fileInfo = new System.IO.FileInfo(this.Context.Parameters["targetdir"] + "\\TeachManageSystem.exe.config");
                if (!fileInfo.Exists)
                {
                    throw new InstallException("û���ҵ������ļ���");
                }

                //ʵ����XML�ĵ�
                System.Xml.XmlDocument xmlDocument = new System.Xml.XmlDocument();
                xmlDocument.Load(fileInfo.FullName);

                //���ҵ�appSettings�еĽڵ�
                bool foundIt = false;
                foreach (System.Xml.XmlNode node in xmlDocument["configuration"]["connectionStrings"])
                {
                    if (node.Name == "add")
                    {
                        if (node.Attributes.GetNamedItem("name").Value == "TeachManageSystem.Settings1.TeachConnectionString")
                        {
                            node.Attributes.GetNamedItem("connectionString").Value = String.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;User ID={2};Password={3}",
                                this.Context.Parameters["server"], 
                                this.Context.Parameters["dbname"], 
                                this.Context.Parameters["user"], 
                                this.Context.Parameters["pwd"]
                            );
                            foundIt = true;
                        }
                    }
                }
                if (!foundIt)
                    throw new InstallException("web.Config �ļ�û�а���ConnectionString�����ַ�������");
                xmlDocument.Save(fileInfo.FullName);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {
                //�����ַ���
                String connStr = String.Format(@"Data Source={0};Initial Catalog={1};Integrated Security=True",
                    this.Context.Parameters["server"], "Master");
                ////������ݿ���ڣ���ɾ�����ݿ�
                //this.ExecuteSql(connStr, "master",
                //    String.Format("IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'{0}') DROP DATABASE [{0}]",this.Context.Parameters["dbname"]));
                //�������ݿ�
                this.ExecuteSql(connStr, "master",
                    String.Format("IF NOT EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'{0}') CREATE DATABASE [{0}] ON ( FILENAME = N'{1}\\{0}_Data.mdf' ),( FILENAME = N'{1}\\{0}_log.ldf' ) FOR ATTACH ",
                           this.Context.Parameters["dbname"],
                           this.Context.Parameters["targetdir"]));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }


}